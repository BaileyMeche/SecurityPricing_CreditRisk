from __future__ import annotations

import logging
import math
from typing import Any
from typing import Sequence
from typing import Union
from typing import cast

import numpy as np
import pandas as pd
from numpy.typing import ArrayLike
from numpy.typing import NDArray
from scipy.stats import norm

from .cashflows import time_adj_dividends
from .implicit import find_present_value
from .instruments import CALL
from .instruments import AmericanOption
from .instruments import EuropeanOption
from .instruments import PricedInstrument
from .term_structures import DiscountFactorFcnType
from .term_structures import TermStructFcnType


logger_bs = logging.getLogger(f"{__name__}.blackscholes")
logger_amr = logging.getLogger(f"{__name__}.american")


_ArrayLike = Union[float, NDArray[Any]]


def _broadcast_vecs(*vecs: ArrayLike) -> tuple[NDArray[Any], ...]:
    """Broadcast scalars / 1-D arrays to a common shape."""
    arrs = [np.asarray(v, dtype=float) for v in vecs]
    shape = np.broadcast(*arrs).shape
    return tuple(np.broadcast_to(a, shape).ravel() for a in arrs)


# ---------------------------------------------------------------------------
# Vectorised Black-Scholes with constant parameters
# ---------------------------------------------------------------------------


def black_scholes(  # noqa: D401
    callput: _ArrayLike,
    S0: _ArrayLike,
    K: _ArrayLike,
    r: _ArrayLike,
    time: _ArrayLike,
    vola: _ArrayLike,
    *,
    default_intensity: _ArrayLike = 0.0,
    divrate: _ArrayLike = 0.0,
    borrow_cost: _ArrayLike = 0.0,
    dividends: pd.DataFrame | None = None,
) -> dict[str, NDArray[Any]]:
    """Vectorised Black–Scholes with jump-to-default and discrete dividends.

    The routine broadcasts all scalar / array inputs to a common shape and
    returns three arrays (`Price`, `Delta`, `Vega`) of that shape.

    Parameters
    ----------
    callput
        Contract flag: ``CALL`` (`+1`) for calls, ``PUT`` (`-1`) for puts.
    S0
        Spot price at valuation time ``t = 0``.
    K
        Strike price.
    r
        Continuously-compounded risk-free rate.
    time
        Time to expiry :math:`T` (years).  Must be strictly positive.
    vola
        Diffusion volatility σ (no jumps to default).
    default_intensity
        Constant hazard rate λ.  The option price is reduced by the survival
        probability ``exp(−λ·T)``; upon default the residual payoff equals
        ``max(0, −callput · K · exp(−r·T))``.
    divrate
        Continuous dividend/foreign-interest yield *q*.
    borrow_cost
        Continuous stock-borrow cost *b* – added to *q* in the drift term.
    dividends
        Optional schedule of discrete dividends.  Must contain columns

        * ``time`` – ex-dates
        * ``fixed`` – fixed cash per share
        * ``proportional`` – fractional of *S* at ex-date

        The amounts are discounted to *t = 0* ignoring default and deducted
        from *S0* (fixed dividends are approximated as proportional).
        For exact treatment use the PDE grid solver instead.

    Returns
    -------
    dict
        ``{"Price": ..., "Delta": ..., "Vega": ...}`` where each value is a
        NumPy array broadcast to the joint input shape.

    Examples
    --------
    Plain put with jump-to-default::

        >>> from ragtop.blackscholes import black_scholes
        >>> from ragtop.instruments import PUT
        >>> res = black_scholes(
        ...     callput=PUT, S0=100, K=90, r=0.03,
        ...     time=1.0, vola=0.5, default_intensity=0.07
        ... )
        >>> res["Price"]

    Call with a single proportional dividend::

        >>> import pandas as pd, numpy as np
        >>> divs = pd.DataFrame({"time": [0.5], "fixed": [0.0], "proportional": [0.02]})
        >>> black_scholes(
        ...     callput=CALL, S0=100, K=110, r=0.02, time=2,
        ...     vola=0.25, dividends=divs
        ... )["Price"]
    """
    # ------------------------------------------------------------------ #
    # Broadcast all inputs to a common np.ndarray shape
    # ------------------------------------------------------------------ #
    callput = np.asarray(callput, dtype=float)
    S0 = np.asarray(S0, dtype=float)
    K = np.asarray(K, dtype=float)
    r = np.asarray(r, dtype=float)
    t = np.asarray(time, dtype=float)
    sigma = np.asarray(vola, dtype=float)
    lamb = np.asarray(default_intensity, dtype=float)
    q_cont = np.asarray(divrate, dtype=float)
    borrow = np.asarray(borrow_cost, dtype=float)

    # ------------------------------------------------------------------ #
    # Discrete dividends → adjust initial spot
    # ------------------------------------------------------------------ #
    if dividends is not None and not dividends.empty:
        mask = (dividends["time"] > 0) & (dividends["time"] <= np.max(t))
        relevant = dividends.loc[mask, ["time", "fixed", "proportional"]]
        if not relevant.empty:
            div_sum = time_adj_dividends(relevant, 0.0, r, h=0.0, S=S0, S0=S0)
            logger_bs.info(f"Found {len(relevant)} dividends – PV sum {div_sum}.")
            S0 = S0 - div_sum

    logger_bs.debug(
        "black_scholes(): callput=%s S0=%s K=%s r=%s t=%s σ=%s λ=%s q=%s b=%s",
        callput,
        S0,
        K,
        r,
        t,
        sigma,
        lamb,
        q_cont,
        borrow,
    )

    # ------------------------------------------------------------------ #
    # Core Black–Scholes formula
    # ------------------------------------------------------------------ #
    sd = sigma * np.sqrt(t)
    q_eff = q_cont + borrow - lamb
    d1 = (np.log(S0 / K) + (r - q_eff) * t + 0.5 * sd**2) / sd
    d2 = d1 - sd

    price_surv = callput * (
        S0 * np.exp(-q_eff * t) * norm.cdf(callput * d1)
        - K * np.exp(-r * t) * norm.cdf(callput * d2)
    )
    delta_surv = np.exp(-q_eff * t) * callput * norm.cdf(callput * d1)
    vega_surv = (
        S0 * np.exp(-q_eff * t) * norm.pdf(d1) * np.sqrt(t) * np.abs(callput)
    )  # ensure same sign for calls/puts

    surv_prob = np.exp(-lamb * t)
    default_payoff = np.maximum(0.0, -callput * K * np.exp(-r * t))

    price = surv_prob * price_surv + (1.0 - surv_prob) * default_payoff
    delta = surv_prob * delta_surv
    vega = surv_prob * vega_surv

    return {"Price": price, "Delta": delta, "Vega": vega}


# ---------------------------------------------------------------------------
# Wrapper that accepts *term-structure* inputs
# ---------------------------------------------------------------------------


def black_scholes_on_term_structures(  # noqa: D401
    callput: NDArray[np.int64] | int | Sequence[int],
    S0: NDArray[np.float64] | float,
    K: NDArray[np.float64] | float,
    time: float,
    *,
    const_volatility: float = 0.5,
    const_short_rate: float = 0.0,
    const_default_intensity: float = 0.0,
    discount_factor_fcn: TermStructFcnType | None = None,
    survival_probability_fcn: TermStructFcnType | None = None,
    variance_cumulation_fcn: TermStructFcnType | None = None,
    dividends: pd.DataFrame | None = None,
    borrow_cost: float = 0.0,
    dividend_rate: float = 0.0,
) -> dict[str, NDArray[Any]]:
    r"""Black–Scholes using **term-structure** inputs.

    Each term-structure argument may be either:

    * a scalar constant (via ``const_*`` parameters), or
    * a callable ``f(T, t)`` returning the discount factor / survival
      probability / variance from *t* to *T*.

    The callable is sampled once at ``(T=time, t=0)`` and collapsed to an
    “equivalent constant” which is then passed to
    :func:`black_scholes`.

    Parameters
    ----------
    callput, S0, K, time
        As in :func:`black_scholes`.
    const_volatility, const_short_rate, const_default_intensity
        Constant fall-backs if the corresponding callable is omitted.
    discount_factor_fcn
        Discount curve ``DF(T, t)``.  If ``None`` defaults to
        ``exp(−const_short_rate·(T − t))``.
    survival_probability_fcn
        Survival curve ``SP(T, t)``.  If ``None`` defaults to
        ``exp(−const_default_intensity·(T − t))``.
    variance_cumulation_fcn
        Cumulated variance :math:`\int_t^T σ^2(u)\,du`.  If ``None`` defaults
        to ``const_volatility**2 · (T − t)``.
    dividends, borrow_cost, dividend_rate
        As in :func:`black_scholes`.

    Returns
    -------
    dict
        Same structure as the output of :func:`black_scholes`.

    Examples
    --------
    Pricing a 1-year put with non-flat curves::

        >>> import math
        >>> from ragtop.blackscholes import black_scholes_on_term_structures
        >>> from ragtop.instruments import PUT
        >>> df  = lambda T, t: math.exp(-0.03 * (T - t))          # flat 3% curve  # noqa: E731
        >>> sp  = lambda T, t: math.exp(-0.07 * (T - t))          # flat 7% hazard  # noqa: E731
        >>> var = lambda T, t: (0.45 ** 2) * (T - t)              # flat 45% vol  # noqa: E731
        >>> black_scholes_on_term_structures(
        ...     callput=PUT, S0=100, K=90, time=1.0,
        ...     discount_factor_fcn=df,
        ...     survival_probability_fcn=sp,
        ...     variance_cumulation_fcn=var
        ... )["Price"]
    """
    if np.any(np.asarray(time) <= 0.0):
        raise ValueError("Expiration `time` must be strictly positive.")

    # Fallback callbacks
    if discount_factor_fcn is None:
        discount_factor_fcn = cast(  # noqa: E731
            DiscountFactorFcnType,
            lambda T, t, r=const_short_rate: math.exp(-r * (T - t)),
        )  # noqa: E731
    if survival_probability_fcn is None:
        survival_probability_fcn = cast(  # noqa: E731
            TermStructFcnType,
            lambda T, t, h=const_default_intensity: math.exp(-h * (T - t)),
        )  # noqa: E731
    if variance_cumulation_fcn is None:
        variance_cumulation_fcn = cast(  # noqa: E731
            TermStructFcnType, lambda T, t, sigma=const_volatility: sigma**2 * (T - t)
        )  # noqa: E731

    # Equivalent constants
    vol_eq = np.sqrt(variance_cumulation_fcn(time, 0.0) / time)
    r_eq = -np.log(discount_factor_fcn(time, 0.0)) / time
    h_eq = -np.log(survival_probability_fcn(time, 0.0)) / time

    logger_bs.debug("Equivalent constants: r=%s, h=%s, σ=%s", r_eq, h_eq, vol_eq)

    return black_scholes(
        callput=np.asarray(callput, dtype=int),
        S0=np.asarray(S0, dtype=float),
        K=np.asarray(K, dtype=float),
        r=r_eq,
        time=time,
        vola=vol_eq,
        default_intensity=h_eq,
        divrate=dividend_rate,
        borrow_cost=borrow_cost,
        dividends=dividends,
    )


def control_variate_pairs(
    callput: NDArray[np.int64] | Sequence[int] | int,
    K: NDArray[np.float64] | Sequence[float] | float,
    time: Sequence[float] | float,
    *,
    discount_factor_fcn: TermStructFcnType | None = None,
) -> list[PricedInstrument]:
    """Return `[A₁..Aₙ, E₁..Eₙ]` where *A* = American, *E* = European."""
    cp, strikes, maturities = _broadcast_vecs(callput, K, time)
    pairs: list[PricedInstrument] = []

    for _idx, (cp_i, K_i, t_i) in enumerate(zip(cp, strikes, maturities, strict=True)):
        tag = f"{'C' if cp_i == CALL else 'P'}_{K_i}_{int(round(365 * t_i))}"
        amer: AmericanOption = AmericanOption(
            maturity=float(t_i),
            strike=float(K_i),
            callput=int(cp_i),
            name=f"A_{tag}",
        )
        euro: EuropeanOption = EuropeanOption(
            maturity=float(t_i),
            strike=float(K_i),
            callput=int(cp_i),
            discount_factor_fcn=discount_factor_fcn,
            name=f"E_{tag}",
        )
        pairs.append(amer)
        pairs.append(euro)

    return pairs


# ---------------------------------------------------------------------------
# Main routine
# ---------------------------------------------------------------------------


def american(
    callput: NDArray[np.int64] | Sequence[int] | int,
    S0: float,
    K: NDArray[Any] | Sequence[float] | float,
    time: float,
    *,
    # Constant fall-backs
    const_short_rate: float = 0.0,
    const_default_intensity: float = 0.0,
    # Optional term-structure callbacks
    discount_factor_fcn: TermStructFcnType | None = None,
    survival_probability_fcn: TermStructFcnType | None = None,
    default_intensity_fcn: TermStructFcnType | None = None,
    # Grid / BS shared kwargs
    dividends: pd.DataFrame | None = None,
    borrow_cost: float = 0.0,
    dividend_rate: float = 0.0,
    const_volatility: float = 0.3,
    variance_cumulation_fcn: TermStructFcnType | None = None,
    # Grid controls
    num_time_steps: int = 100,
    structure_constant: float = 2.0,
    std_devs_width: float = 5.0,
    # Extra keyword arguments forwarded to find_present_value / BS wrapper
    **kwargs: Any,
) -> NDArray[Any]:
    """Present value of American options via control-variate adjustment.

    Parameters
    ----------
    callput
        ``CALL`` (+1) or ``PUT`` (−1); scalar or 1-D array.
    S0
        Spot equity price at *t = 0*.
    K
        Strike(s).
    time
        Time(s) to maturity (years).
    const_short_rate, const_default_intensity
        Used when the corresponding term-structure callbacks are omitted.
    discount_factor_fcn, survival_probability_fcn, default_intensity_fcn,
    variance_cumulation_fcn, dividends, borrow_cost, dividend_rate
        Passed through to both the Black–Scholes and grid engines.
    num_time_steps, structure_constant, std_devs_width
        Finite-difference grid controls.
    **kwargs
        Any additional parameters accepted by
        :func:`black_scholes_on_term_structures` or
        :func:`find_present_value`.

    Returns
    -------
    numpy.ndarray
        Array of American option present values with the same broadcast shape
        as ``np.broadcast(callput, K, time)``.

    Examples
    --------
    Vanilla put with constant parameters::

        >>> from ragtop.blackscholes import american
        >>> from ragtop.instruments import PUT
        >>> american(PUT, S0=100, K=110, time=0.75,
        ...          const_short_rate=0.06, const_volatility=0.2,
        ...          num_time_steps=200)

    Vectorised call/put mix with a volatility term structure::

        >>> import numpy as np
        >>> var_ts = lambda T, t: 0.45**2 * (T - t) + 0.15**2 * (np.asarray(T)-0.25).clip(min=0)
        >>> american(np.array([CALL, PUT]), S0=100,
        ...          K=np.array([105, 90]), time=np.array([0.5, 1.0]),
        ...          variance_cumulation_fcn=var_ts)
    """
    # ------------------------------------------------------------------ #
    # Fallback term structures (flat curves)
    # ------------------------------------------------------------------ #
    if discount_factor_fcn is None:
        discount_factor_fcn = cast(  # noqa: E731
            DiscountFactorFcnType,
            lambda T, t, r=const_short_rate: np.exp(-r * (T - t)),
        )  # noqa: E731
    if survival_probability_fcn is None:
        survival_probability_fcn = cast(  # noqa: E731
            TermStructFcnType,
            lambda T, t, h=const_default_intensity: np.exp(-h * (T - t)),
        )  # noqa: E731
    if variance_cumulation_fcn is None:
        variance_cumulation_fcn = cast(  # noqa: E731
            TermStructFcnType, lambda T, t, sig=const_volatility: sig**2 * (T - t)
        )  # noqa: E731
    if default_intensity_fcn is None:
        default_intensity_fcn = cast(  # noqa: E731
            TermStructFcnType, lambda t, S, h=const_default_intensity: h + 0.0 * S
        )  # noqa: E731

    # ------------------------------------------------------------------ #
    # Exact European prices (Black–Scholes w/ term structures)
    # ------------------------------------------------------------------ #
    bs_res = black_scholes_on_term_structures(
        callput=np.asarray(callput, dtype=int),
        S0=np.asarray(S0, dtype=float),
        K=np.asarray(K, dtype=float),
        time=time,
        const_short_rate=const_short_rate,
        const_default_intensity=const_default_intensity,
        discount_factor_fcn=discount_factor_fcn,
        survival_probability_fcn=survival_probability_fcn,
        variance_cumulation_fcn=variance_cumulation_fcn,
        dividends=dividends,
        borrow_cost=borrow_cost,
        dividend_rate=dividend_rate,
        **kwargs,
    )
    exact_euro_prices = np.asarray(bs_res["Price"]).ravel()

    logger_amr.debug(
        "Exact BS European prices range %.6g → %.6g",
        np.min(exact_euro_prices),
        np.max(exact_euro_prices),
    )

    # ------------------------------------------------------------------ #
    # Control-variate instrument set & grid pricing
    # ------------------------------------------------------------------ #
    instrs = control_variate_pairs(
        callput=callput,
        K=K,
        time=time,
        discount_factor_fcn=discount_factor_fcn,
    )
    n_pairs = len(instrs) // 2

    grid_vals = find_present_value(
        S0=S0,
        num_time_steps=num_time_steps,
        instruments=instrs,
        const_short_rate=const_short_rate,
        const_default_intensity=const_default_intensity,
        discount_factor_fcn=discount_factor_fcn,
        default_intensity_fcn=default_intensity_fcn,
        variance_cumulation_fcn=variance_cumulation_fcn,
        dividends=dividends,
        borrow_cost=borrow_cost,
        dividend_rate=dividend_rate,
        structure_constant=structure_constant,
        std_devs_width=std_devs_width,
        **kwargs,
    )

    # Respect insertion order (Py ≥3.7)
    grid_amer_prices = np.array([grid_vals[i.name] for i in instrs[:n_pairs]])
    grid_euro_prices = np.array([grid_vals[i.name] for i in instrs[n_pairs:]])

    # ------------------------------------------------------------------ #
    # Control-variate correction
    # ------------------------------------------------------------------ #
    euro_errors = exact_euro_prices - grid_euro_prices
    logger_amr.debug(
        "European grid error range %.6g → %.6g",
        np.min(euro_errors),
        np.max(euro_errors),
    )

    cv_amer = grid_amer_prices + euro_errors

    # ------------------------------------------------------------------ #
    # Ensure ≥ intrinsic value (early exercise floor)
    # ------------------------------------------------------------------ #
    callput_vec, strike_vec, _ = _broadcast_vecs(callput, K, time)
    intrinsic = np.maximum(callput_vec * (S0 - strike_vec), 0.0)
    cv_amer = np.maximum(cv_amer, intrinsic)

    # Return reshaped to broadcast shape
    shape = np.broadcast(callput, K, time).shape
    return cv_amer.reshape(shape)
