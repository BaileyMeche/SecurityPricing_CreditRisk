from __future__ import annotations

import logging
from typing import Any
from typing import Protocol

import numpy as np
import pandas as pd
from numpy.typing import NDArray

from .term_structures import DiscountFactorFcnType
from .term_structures import trivial_discounting


logger_instr = logging.getLogger(f"{__name__}.instruments")
logger_bond = logging.getLogger(f"{__name__}.bond")

# ---------------------------------------------------------------------------
# Public constants
# ---------------------------------------------------------------------------


TIME_RESOLUTION_FACTOR: float = 1e-8
TIME_EPS: float = 1e-12

CALL: int = 1
PUT: int = -1


# Notes:
# As a convention, discount_factor_fctn is used for convenience discount factor callables supplied to
# objects as instance variables, while discount_factor_fcn is used as the variable name of callables sent
# to object methods for calculation.  When both are present, the latter takes precedence.

# ---------------------------------------------------------------------------
# Type protocol (static typing aid only)
# ---------------------------------------------------------------------------


class PricedInstrument(Protocol):  # pragma: no cover
    """Structural contract an object must satisfy to be usable by ragtop.

    Note some function arguments are expected to be None, always or
     sometimes, for some instrument types
    """

    maturity: float
    last_computed_grid: NDArray[Any] | None
    name: str

    # These methods must exist with the indicated signatures
    def recovery_fcn(
        self,
        v: NDArray[Any],
        S: NDArray[Any],
        t: float,
        *,
        discount_factor_fcn: DiscountFactorFcnType | None = None,
    ) -> NDArray[Any]: ...

    def optionality_fcn(
        self,
        v: NDArray[Any],
        S: NDArray[Any],
        t: float,
        *,
        discount_factor_fcn: DiscountFactorFcnType | None = None,
    ) -> NDArray[Any]: ...

    def terminal_values(
        self,
        v: NDArray[Any],
        S: NDArray[Any],
        t: float,
        *,
        discount_factor_fcn: DiscountFactorFcnType | None = None,
    ) -> NDArray[Any]: ...

    # Optional helpers recognised by the solver
    def critical_times(self) -> NDArray[Any]: ...
    def update_cashflows(
        self,
        t_start: float,
        t_end: float,
        *,
        discount_factor_fcn: DiscountFactorFcnType | None = None,
    ) -> float | NDArray[Any]: ...


# ---------------------------------------------------------------------------
# Concrete implementations
# ---------------------------------------------------------------------------


class GridPricedInstrument:
    """Minimal base class for PDE-priced instruments.

    Attributes
    ----------
    maturity
        Time (years) at which the instrument’s final cash-flow occurs.
    last_computed_grid
        Cache of the most recent value vector produced by the PDE solver.
        This can be useful for path-dependent contracts.
    name
        Human-readable identifier used only in log output.
    """

    maturity: float
    last_computed_grid: NDArray[Any] | None
    name: str

    # ------------------------------------------------------------------ #
    # Construction
    # ------------------------------------------------------------------ #
    def __init__(self, maturity: float, *, name: str | None = None) -> None:
        self.maturity = float(maturity)
        self.name = name or self.__class__.__name__
        self.last_computed_grid = None

    # ------------------------------------------------------------------ #
    # Duck-typed interface expected by the solver
    # ------------------------------------------------------------------ #
    def recovery_fcn(  # noqa: D401
        self,
        v: NDArray[Any],
        S: NDArray[Any],
        t: float,
        *,
        discount_factor_fcn: DiscountFactorFcnType | None = None,
    ) -> NDArray[Any]:
        """Return recovery values at default (default implementation = 0)."""
        return np.zeros_like(S)

    def optionality_fcn(  # noqa: D401
        self,
        v: NDArray[Any],
        S: NDArray[Any],
        t: float,
        *,
        discount_factor_fcn: DiscountFactorFcnType | None = None,
    ) -> NDArray[Any]:
        """Correct for optionality.  Base implementation is a passthrough."""
        self.last_computed_grid = v.copy()
        return v

    def terminal_values(
        self,
        v: NDArray[Any],
        S: NDArray[Any],
        t: float,
        *,
        discount_factor_fcn: DiscountFactorFcnType | None = None,
    ) -> NDArray[Any]:
        """Return terminal payoff at *t = maturity*.

        Default behaviour defers to :pymeth:`optionality_fcn`.
        """
        return self.optionality_fcn(v, S, t, discount_factor_fcn=discount_factor_fcn)

    # Many instruments do **not** need the following helpers, so they are
    # provided as stubs only.
    def critical_times(self) -> NDArray[Any]:  # noqa: D401
        """Extra grid times demanded by contract terms (default: none)."""
        return np.empty(0)

    def update_cashflows(self, *args, **kwargs) -> float | NDArray[Any]:  # type: ignore[no-untyped-def]
        """Optional callback invoked each step to inject known cash-flows."""
        return 0.0


# ---------------------------------------------------------------------------
# Options
# ---------------------------------------------------------------------------


class EquityOption(GridPricedInstrument):
    """Base class shared by call/put options.

    Parameters
    ----------
    strike
        Strike price *K*.
    callput
        ``+1`` for call, ``−1`` for put.
    """

    def __init__(
        self,
        maturity: float,
        strike: float,
        callput: int,
        *,
        name: str | None = None,
    ) -> None:
        super().__init__(maturity, name=name)
        self.strike = float(strike)
        if callput not in (+1, -1):
            raise ValueError("callput flag must be +1 (call) or -1 (put)")
        self.callput = int(callput)


# ------------------------------------------------------------------ #
# European Option
# ------------------------------------------------------------------ #


class EuropeanOption(EquityOption):
    """Plain-vanilla European call or put option."""

    def __init__(
        self,
        maturity: float,
        strike: float,
        callput: int,
        discount_factor_fcn: DiscountFactorFcnType | None = None,
        *,
        name: str | None = None,
    ) -> None:
        super().__init__(maturity, strike, callput, name=name)
        self._discount_factor_fcn: DiscountFactorFcnType = (
            discount_factor_fcn or trivial_discounting
        )

    # --------------------------------------------- recovery (default leg) ---
    def recovery_fcn(  # noqa: D401
        self,
        v: NDArray[Any],
        S: NDArray[Any],
        t: float,
        *,
        discount_factor_fcn: (
            DiscountFactorFcnType | None
        ) = None,  # Allow overriding df in object
    ) -> NDArray[Any]:
        """Return zero for calls and discounted strike for puts."""
        if self.callput == -1:  # put
            dfcn: DiscountFactorFcnType = (
                discount_factor_fcn or self._discount_factor_fcn
            )
            df = dfcn(self.maturity, t)
            recovery = self.strike * df
            if recovery > 2 * np.max(S):
                logger_instr.warning(
                    f"{self.name}: unusually large recovery {recovery} "
                    f"(strike={self.strike}, df={df}, max(S)={np.max(S)})."
                )
            return np.full_like(S, recovery)
        return np.zeros_like(S)

    # -------------------------------------------------- optionality payoff ---
    def optionality_fcn(  # noqa: D401
        self,
        v: NDArray[Any],
        S: NDArray[Any],
        t: float,
        *,
        discount_factor_fcn: DiscountFactorFcnType | None = None,  # Unused
    ) -> NDArray[Any]:
        """Return continuation value up to maturity; intrinsic thereafter."""
        out = v.copy()
        if t >= self.maturity:
            out = self.callput * (S - self.strike)
        out = np.maximum(out, 0.0)
        self.last_computed_grid = out.copy()
        return out


# ------------------------------------------------------------------ #
# American Option
# ------------------------------------------------------------------ #


class AmericanOption(EquityOption):
    """American option allowing exercise at any time ≤ maturity."""

    # --------------------------------------------- recovery (default leg) ---
    def recovery_fcn(  # noqa: D401
        self,
        v: NDArray[Any],
        S: NDArray[Any],
        t: float,
        *,
        discount_factor_fcn: DiscountFactorFcnType | None = None,
    ) -> NDArray[Any]:
        """Return zero for calls and strike for puts (undiscounted)."""
        if self.callput == PUT:
            return np.full_like(S, self.strike)
        return np.zeros_like(S)

    # -------------------------------------------------- optionality payoff ---
    def optionality_fcn(  # noqa: D401
        self,
        v: NDArray[Any],
        S: NDArray[Any],
        t: float,
        *,
        discount_factor_fcn: DiscountFactorFcnType | None = None,
    ) -> NDArray[Any]:
        """Apply early-exercise rule for American options."""
        out = v.copy()

        intrinsic = self.callput * (S - self.strike)
        intrinsic = np.maximum(intrinsic, 0.0)

        if t < self.maturity:
            exercise = intrinsic > out
            out[exercise] = intrinsic[exercise]
        else:  # beyond maturity: option is worth intrinsic only
            out = intrinsic

        opty: NDArray[Any] = np.maximum(out, 0.0)
        self.last_computed_grid = opty.copy()
        return opty


class ZeroCouponBond(GridPricedInstrument):
    """Simple zero-coupon bond paying *notional* at *maturity*."""

    def __init__(  # type: ignore[no-untyped-def]
        self,
        maturity: float,
        notional: float = 1.0,
        recovery_rate=0.0,
        *,
        discount_factor_fctn: DiscountFactorFcnType | None = None,
        name: str | None = None,
    ) -> None:
        super().__init__(maturity, name=name)
        self._discount_factor_fcn = discount_factor_fctn
        self.notional = float(notional)
        self.recovery_rate = float(recovery_rate)

    # ------------------------------------------------------------------ #
    # Cash-flows & option adjustments
    # ------------------------------------------------------------------ #

    def optionality_fcn(  # noqa: D401
        self,
        v: NDArray[Any],
        S: NDArray[Any],
        t: float,
        *,
        discount_factor_fcn: DiscountFactorFcnType | None = None,  # Unused
    ) -> NDArray[Any]:
        """No optionality → passthrough except beyond maturity (value = 0)."""
        if t >= self.maturity:
            out = np.zeros_like(v + S) + self.notional
        else:
            out = np.maximum(v, 0.0)
        self.last_computed_grid = out.copy()
        return out

    def recovery_fcn(
        self,
        v: NDArray[Any],
        S: NDArray[Any],
        t: float,
        *,
        discount_factor_fcn: DiscountFactorFcnType | None = None,  # Unused
    ) -> NDArray[Any]:
        """Recovery nontrivial if we have a rate set."""
        if t < self.maturity and self.recovery_rate is not None:
            recovery = 0.0 * v + self.recovery_rate * self.notional
            recovery[v < recovery] = v[v < recovery]
            recovery = recovery + 0 * S  # ensure proper shape
        else:
            recovery = np.zeros_like(v + S)

        return recovery


# ---------------------------------------------------------------------------
# Fixed-coupon bond
# ---------------------------------------------------------------------------


class CouponBond(ZeroCouponBond):
    """Fixed-coupon bond; coupons accrue after payment and earn *r*."""

    def __init__(  # type: ignore[no-untyped-def]
        self,
        maturity: float,
        notional: float = 1.0,
        recovery_rate=0.0,
        coupons: pd.DataFrame | None = None,
        *,
        discount_factor_fctn: DiscountFactorFcnType | None,
        name: str | None = None,
    ) -> None:
        """
        Parameters
        ----------
        coupons
            Data-frame with columns ``payment_time`` and ``payment_size``.
        discount_factor_fcn
            Risk-free discount curve ``DF(T, t)`` used for coupon accrual.
        """
        super().__init__(
            maturity=maturity, notional=notional, recovery_rate=recovery_rate, name=name
        )
        if coupons is None:
            self.coupons = pd.DataFrame(columns=["payment_time", "payment_size"])
        else:
            self.coupons = coupons.copy().sort_values("payment_time")
        self._discount_factor_fcn = discount_factor_fctn
        self.last_computed_cash: float | None = None

    # ------------------------------------------------------------------ #
    # Internals
    # ------------------------------------------------------------------ #

    def _accumulate_coupons_before(
        self, t: float, discount_factor_fcn: DiscountFactorFcnType | None = None
    ) -> float:
        """Sum PV (as-of *t*) of coupons already paid ≤ *t*."""
        mask = (
            self.coupons["payment_time"] <= t + self.maturity * TIME_RESOLUTION_FACTOR
        )
        if not mask.any():
            return 0.0
        paid = self.coupons.loc[mask]
        dfcn = discount_factor_fcn or self._discount_factor_fcn or trivial_discounting
        acc_props = dfcn(t, paid["payment_time"].to_numpy())
        acc = (paid["payment_size"].to_numpy() / acc_props).sum()
        logger_bond.info(f"{self.name}: accrued coupons up to t={t} = {acc:.6g}.")
        return float(acc)

    def _coupons_between(
        self,
        t0: float,
        t1: float,
        discount_factor_fcn: DiscountFactorFcnType | None = None,
    ) -> float:
        """PV at *t1* of coupons whose ex-dates lie in *(t0, t1].*"""
        mask = (self.coupons["payment_time"] > t0) & (
            self.coupons["payment_time"] <= t1 + TIME_EPS
        )
        if not mask.any():
            return 0.0
        paid = self.coupons.loc[mask]
        dfcn = discount_factor_fcn or self._discount_factor_fcn or trivial_discounting
        acc_props = dfcn(t1, paid["payment_time"].to_numpy())
        val = (acc_props * paid["payment_size"].to_numpy()).sum()
        logger_bond.info(
            f"{self.name}: PV of coupons in ({t0}, {t1}] = {val:.6g} (at t={t1})."
        )
        return float(val)

    # ------------------------------------------------------------------ #
    # PDE-solver hooks
    # ------------------------------------------------------------------ #

    def critical_times(self) -> NDArray[Any]:  # noqa: D401
        """Return maturity plus all coupon dates."""
        times = np.append(self.maturity, self.coupons["payment_time"].to_numpy())
        return np.unique(np.sort(times))

    def update_cashflows(
        self,
        t_start: float,
        t_end: float,
        *,
        discount_factor_fcn: DiscountFactorFcnType | None = None,
        include_notional: bool = True,
    ) -> float | NDArray[Any]:
        """
        Return PV (at *t_end*) of coupons and, optionally, notional inside
        *(t_start, t_end].*  Also updates ``last_computed_cash`` with the new
        accrued amount **discounted back to *t_start***.
        """
        if self.last_computed_cash is None:
            self.last_computed_cash = 0.0

        coup = self._coupons_between(
            t_start, t_end, discount_factor_fcn=discount_factor_fcn
        )
        dfcn = discount_factor_fcn or self._discount_factor_fcn or trivial_discounting
        notional_cf = 0.0
        if (
            include_notional
            and (self.maturity > t_start)
            and (self.maturity <= t_end + TIME_EPS)
        ):
            notional_cf = self.notional * dfcn(self.maturity, t_end)

        total_cf = coup + notional_cf
        df = dfcn(t_end, t_start)
        new_cash = df * (self.last_computed_cash - total_cf)

        logger_bond.info(
            f"{self.name}: cash-flows ({t_start}, {t_end}] total={total_cf:.6g}; "
            f"updating last_computed_cash from {self.last_computed_cash:.6g} "
            f"to {new_cash:.6g} using DF={df:.6g}."
        )

        self.last_computed_cash = new_cash
        return total_cf

    def optionality_fcn(  # noqa: D401
        self,
        v: NDArray[Any],
        S: NDArray[Any],
        t: float,
        *,
        discount_factor_fcn: DiscountFactorFcnType | None = None,  # Unused
    ) -> NDArray[Any]:
        """No early exercise; zero value beyond maturity."""
        if t >= self.maturity - TIME_EPS:
            accrued = self._accumulate_coupons_before(
                self.maturity, discount_factor_fcn=discount_factor_fcn
            )
            self.last_computed_cash = self.notional + accrued
            logger_bond.info(
                f"{self.name}: at t={t} ≥ maturity, set last_computed_cash to "
                f"{self.last_computed_cash:.6g}."
            )
            out = np.zeros_like(v)
        else:
            out = np.maximum(v, 0.0)
            self.last_computed_grid = out.copy()
        return out


# ---------------------------------------------------------------------------
# Callable / putable bond
# ---------------------------------------------------------------------------


class CallableBond(CouponBond):
    """Coupon bond with call and/or put schedules."""

    def __init__(  # type: ignore[no-untyped-def]
        self,
        maturity: float,
        notional: float = 1.0,
        recovery_rate=0.0,
        *,
        coupons: pd.DataFrame | None = None,
        calls: pd.DataFrame | None = None,
        puts: pd.DataFrame | None = None,
        discount_factor_fctn: DiscountFactorFcnType | None = None,
        name: str | None = None,
    ) -> None:
        super().__init__(
            maturity=maturity,
            coupons=coupons,
            notional=notional,
            recovery_rate=recovery_rate,
            discount_factor_fctn=discount_factor_fctn,
            name=name,
        )
        self.calls = calls.copy() if calls is not None else pd.DataFrame()
        self.puts = puts.copy() if puts is not None else pd.DataFrame()

    def critical_times(self) -> NDArray[Any]:  # noqa: D401
        """Maturity + coupon + call + put dates."""
        times = [self.maturity]
        if not self.coupons.empty:
            times = times + list(self.coupons["payment_time"].to_numpy())
        if not self.calls.empty:
            times + list(self.calls["effective_time"].to_numpy())
        if not self.puts.empty:
            times + list(self.puts["effective_time"].to_numpy())
        return np.unique(np.sort(np.array(times)))


# ---------------------------------------------------------------------------
# Convertible bond
# ---------------------------------------------------------------------------


class ConvertibleBond(CallableBond):
    """Convertible bond paying coupons and optionally exchangeable into equity."""

    def __init__(  # type: ignore[no-untyped-def]
        self,
        maturity: float,
        notional: float = 1.0,
        recovery_rate=0.0,
        *,
        coupons: pd.DataFrame | None = None,
        conversion_ratio: float,
        dividend_ceiling: float | None = None,
        discount_factor_fctn: DiscountFactorFcnType | None = None,
        calls: pd.DataFrame | None = None,
        puts: pd.DataFrame | None = None,
        name: str | None = None,
    ) -> None:
        super().__init__(
            maturity=maturity,
            coupons=coupons,
            calls=calls,
            puts=puts,
            notional=notional,
            recovery_rate=recovery_rate,
            discount_factor_fctn=discount_factor_fctn,
            name=name,
        )
        self.conversion_ratio = float(conversion_ratio)
        self.dividend_ceiling = (
            None if dividend_ceiling is None else float(dividend_ceiling)
        )

        # Memoization caches
        self.last_computed_exercise_value: NDArray[Any] | None = None
        self.last_computed_exercise_decision: NDArray[Any] | None = None
        self.last_used_S: NDArray[Any] | None = None
        self.last_used_t: float | None = None

    # ------------------------------------------------------------------ #
    # Exercise logic helpers
    # ------------------------------------------------------------------ #

    def _compute_exercise_decision(
        self,
        v: NDArray[Any],
        S: NDArray[Any],
        t: float,
        discount_factor_fcn: DiscountFactorFcnType | None = None,
    ) -> None:
        """Populate memoisation fields with latest exercise decision."""
        logger_bond.info(f"{self.name}: evaluating exercise at t={t}.")
        exercise_values = S * self.conversion_ratio

        if t >= self.maturity - TIME_EPS and np.all(v <= 0):
            total_early_value = exercise_values
        else:
            accrued = self._accumulate_coupons_before(
                t, discount_factor_fcn=discount_factor_fcn
            )
            total_early_value = exercise_values + accrued

        diff = v - total_early_value
        logger_bond.info(
            f"{self.name}: grid minus exercise ranges [{np.min(diff):.6g}, "
            f"{np.max(diff):.6g}], avg={np.mean(diff):.6g}."
        )

        exercise_ix = diff < 0.0
        self.last_computed_exercise_decision = exercise_ix
        self.last_computed_exercise_value = total_early_value
        self.last_used_S = S.copy()
        self.last_used_t = t

    def _exercise_decision(
        self,
        v: NDArray[Any],
        S: NDArray[Any],
        t: float,
        discount_factor_fcn: DiscountFactorFcnType | None = None,
    ) -> tuple[NDArray[Any], NDArray[Any]]:
        """Return tuple (exercise_indexes, exercise_values)."""
        need_recalc = (
            self.last_computed_exercise_decision is None
            or self.last_used_t is None
            or self.last_used_S is None
            or t != self.last_used_t
            or not np.array_equal(S, self.last_used_S)
        )
        if need_recalc:
            self._compute_exercise_decision(
                v, S, t, discount_factor_fcn=discount_factor_fcn
            )
        else:
            logger_bond.info(f"{self.name}: reusing cached exercise decision at t={t}.")
        assert self.last_computed_exercise_decision is not None  # nosec B101
        assert self.last_computed_exercise_value is not None  # nosec B101

        return (
            self.last_computed_exercise_decision,
            self.last_computed_exercise_value,
        )

    # ------------------------------------------------------------------ #
    # PDE hooks
    # ------------------------------------------------------------------ #

    def update_cashflows(
        self,
        t_start: float,
        t_end: float,
        *,
        discount_factor_fcn: DiscountFactorFcnType | None = None,
        include_notional: bool = False,  # This argument will be overridden below
    ) -> float | NDArray[Any]:
        """
        Cash-flows are the same as a straight bond **except** any nodes that
        have exercised into stock receive *zero* coupon / notional.
        """
        base_cf = super().update_cashflows(
            t_start,
            t_end,
            discount_factor_fcn=discount_factor_fcn,
            include_notional=False,
        )

        # If exercise decision not available, treat as straight bond
        if (
            self.last_computed_grid is None
            or self.last_computed_exercise_decision is None
        ):
            logger_bond.info(
                f"{self.name}: no exercise info; using straight-bond cash-flow "
                f"{base_cf:.6g}."
            )
            return base_cf

        cf_array = np.full_like(self.last_computed_grid, base_cf)
        cf_array[self.last_computed_exercise_decision] = 0.0
        logger_bond.info(
            f"{self.name}: zeroed cash-flows at "
            f"{self.last_computed_exercise_decision.sum()} exercise nodes."
        )
        return cf_array

    def optionality_fcn(  # noqa: D401
        self,
        v: NDArray[Any],
        S: NDArray[Any],
        t: float,
        *,
        discount_factor_fcn: DiscountFactorFcnType | None = None,
    ) -> NDArray[Any]:
        """Maximum of hold value and (stock × ratio + accrued coupons)."""
        ix, ex_val = self._exercise_decision(v, S, t, discount_factor_fcn)
        out = v.copy()
        out[ix] = ex_val[ix]
        self.last_computed_grid = out.copy()
        return out

    def terminal_values(
        self,
        v: NDArray[Any],
        S: NDArray[Any],
        t: float,
        *,
        discount_factor_fcn: DiscountFactorFcnType | None = None,
    ) -> NDArray[Any]:
        """Payoff at *t = maturity* considering conversion choice."""
        notional_leg = np.full_like(S, self.notional)
        stock_leg = S * self.conversion_ratio

        pay = np.where(stock_leg > notional_leg, stock_leg, notional_leg)
        logger_bond.info(
            f"{self.name}: terminal payoff uses stock in "
            f"{np.sum(stock_leg > notional_leg)} of {S.size} nodes "
            f"(ratio={self.conversion_ratio})."
        )
        return pay
