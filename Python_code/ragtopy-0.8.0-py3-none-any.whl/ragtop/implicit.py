from __future__ import annotations

import logging
import math
from typing import Any
from typing import Callable
from typing import Iterable
from typing import Mapping
from typing import Sequence
from typing import cast

import numpy as np
import pandas as pd
from numpy.typing import NDArray
from scipy.linalg.lapack import dgtsv

from .cashflows import adjust_for_dividends
from .extrapolation import spline_extrapolate
from .instruments import PricedInstrument  # structural protocol
from .term_structures import DiscountFactorFcnType
from .term_structures import TermStructFcnType


logger_setup = logging.getLogger(f"{__name__}.setup")
logger_width = logging.getLogger(f"{__name__}.setup.width")
logger_tri = logging.getLogger(f"{__name__}.construct_tridiagonals")
logger_step = logging.getLogger(f"{__name__}.timestep")
logger_iter = logging.getLogger(f"{__name__}.iterate")
logger_intg = logging.getLogger(f"{__name__}.integrate")
logger_pv = logging.getLogger(f"{__name__}.form_present_value_grid")
logger_find = logging.getLogger(f"{__name__}.find_present_value")

TIME_RESOLUTION_SIGNIF_DIGITS: int = 8


def construct_implicit_grid_structure(
    tenors: Iterable[float],
    M: int,
    S0: float,
    K: float,
    c: float,
    sigma: float,
    structure_constant: float,
    std_devs_width: float,
    min_z_width: float = 0.0,  # kept for signature compatibility; currently unused
) -> dict[str, Any]:
    """Infer a reasonable grid for an implicit finite-difference PDE solver.

    The routine mirrors the behaviour of `construct_implicit_grid_structure`
    from the original *ragtop* R package.

    The spatial grid is built in *log-price* space *z* = ln *S*, while the time
    discretisation spans from *t* = 0 to *T* = max(`tenors`).  Grid spacing is
    driven by the requirement that ::

        dz = sqrt(dt / structure_constant) ,
        dt = T / M .

    The total half-width of the spatial grid is chosen to cover a user-specified
    number of standard deviations of the diffusion process.

    Args:
        tenors: Collection of positive times to maturity.  The largest value
            determines the time horizon *T* of the grid.
        M: Minimum number of time steps.
        S0: Current underlying price.
        K: Reference (e.g. strike) price — used to centre the grid.
        c: Continuous drift rate of the underlying.
        sigma: Volatility of the diffusion component (excludes jumps to default).
        structure_constant: Maximum ratio ``dt / dz**2`` controlling numerical
            stability.
        std_devs_width: Desired half-width of the grid expressed in units of
            ``sigma * sqrt(T)``.
        min_z_width: Minimum half-width in log-price space.  Present for API
            compatibility; not currently enforced.

    Returns:
        dict: A mapping with the following keys (mirroring the R structure):

            * ``T`` – maximum time horizon.
            * ``dt`` – time-step size.
            * ``dz`` – spatial step size.
            * ``z0`` – centre of the spatial grid.
            * ``z_width`` – total half-width of the grid in *z* space.
            * ``half_N`` – equal to ``ceil(z_width / dz)``.
            * ``N`` – number of spatial nodes (``2 * half_N + 1``).
            * ``z`` – ``numpy.ndarray`` with the *z* coordinates of the grid.

    Notes:
        Very small volatilities relative to the chosen time-step size can lead
        to an undersampled spatial grid.  In such situations a warning is
        emitted and downstream results should be interpreted with care.
    """
    # -----------------------------------------------------------------------
    # Basic grid scalars
    # -----------------------------------------------------------------------
    T: float = max(tenors)
    dt: float = T / M
    z0: float = math.log(S0 / K) + (c - 0.5 * sigma**2) * T
    dz: float = math.sqrt(dt / structure_constant)
    z_width: float = std_devs_width * sigma * math.sqrt(T)

    logger_setup.info(
        f"construct_implicit_grid_structure(T={T}, M={M}, S0={S0}, K={K}, "
        f"c={c}, sigma={sigma}, structure_constant={structure_constant}, "
        f"std_devs_width={std_devs_width})"
    )

    # -----------------------------------------------------------------------
    # Sanity check on spatial resolution
    # -----------------------------------------------------------------------
    if dz * 4.0 > z_width:
        logger_width.warning(
            f"Volatility {sigma:.6g} is tiny relative to time-step size {dt:.6g}; "
            "only a few spatial points will be used.  PDE accuracy may suffer."
        )

    # -----------------------------------------------------------------------
    # Assemble the spatial grid
    # -----------------------------------------------------------------------
    half_N: int = math.ceil(z_width / dz)
    N: int = 2 * half_N + 1
    z: NDArray[Any] = z0 + dz * np.arange(-half_N, half_N + 1, dtype=float)

    logger_setup.info(
        f"Grid structure: M={M}, dt={dt:.6g}, T={T:.6g}, sigma={sigma:.6g} "
        f"→ N={N} spatial points (dz={dz:.6g}, ±{std_devs_width}σ, "
        f"z_width={z_width:.6g})."
    )

    # -----------------------------------------------------------------------
    # Return structure
    # -----------------------------------------------------------------------
    return {
        "T": T,
        "dt": dt,
        "dz": dz,
        "z0": z0,
        "z_width": z_width,
        "half_N": half_N,
        "N": N,
        "z": z,
    }


def construct_tridiagonals(
    sigma: float,
    structure_constant: float,
    drift: NDArray[Any],
) -> dict[str, NDArray[Any]]:
    """Return the sub/super/diagonals for the implicit FD scheme.

    A Neumann (zero-delta) boundary condition is enforced at the two ends.

    Args:
        sigma: Volatility of the diffusion component (no jumps).
        structure_constant: Ratio ``dt / dz**2``.
        drift: Array of drift rates for every spatial node (includes any
            default-induced drift).

    Returns:
        dict with keys ``sub``, ``diag`` and ``super`` (NumPy 1-D arrays).
    """
    N = drift.size
    diag = np.full(N, 1.0 + sigma**2 * structure_constant)

    subdiag = -0.5 * (sigma**2 * structure_constant - drift[1:])  # length N-1
    superdiag = -0.5 * (sigma**2 * structure_constant + drift[:-1])  # length N-1

    # Neumann BCs
    neumann_low = drift[0]
    diag[0] = 1.0 + neumann_low
    superdiag[0] = -neumann_low

    neumann_high = drift[-1]
    diag[-1] = 1.0 + neumann_high
    subdiag[-1] = -neumann_high

    # Stability / invertibility warning
    core = np.abs(diag[1:-1]) - np.abs(subdiag[:-1]) - np.abs(superdiag[1:])
    bad_ix = np.where(core < 0)[0] + 1  # shift for the slice offset
    if bad_ix.size:
        logger_tri.info(
            f"Potentially singular implicit matrix; suspect rows: {bad_ix.tolist()}"
        )

    return {"sub": subdiag, "diag": diag, "super": superdiag}


def take_implicit_timestep(
    t: float,
    S: NDArray[Any],
    full_discount_factor: float,
    local_discount_factor: float,
    discount_factor_fcn: DiscountFactorFcnType,
    prev_grid_values: NDArray[Any],
    survival_probabilities: NDArray[Any],
    tridiag_matrix_entries: Mapping[str, NDArray[Any]],
    instrument: PricedInstrument | None = None,
    dividends: pd.DataFrame | None = None,
    instr_name: str = "instrument",
) -> NDArray[Any]:
    """Step one implicit layer backward for a single instrument.

    The routine solves the tridiagonal linear system that arises from an
    θ-scheme with θ = 1 (fully implicit) and then combines survival and
    default-recovery legs to obtain the ex-default value at time *t*.

    Args:
        t: Valuation time **after** the step has been taken – i.e. the solver
            moves from *t + dt* back to *t*.
        S: Stock-price grid (length *N*), obtained from the space grid *z*
            through the supplied `stock_level_fcn` in the caller.
        full_discount_factor: Discount factor from time *0* to *t*
            ``DF(t, 0)``.  Used to map between discounted grid values and
            outright prices.
        local_discount_factor: Discount factor from *t* to *t + dt*
            ``DF(t+dt, t)``.  Appears in the default-recovery leg.
        discount_factor_fcn: Callable ``DF(T, t)`` that returns the price at
            time *t* of one monetary unit payable at *T*.  Passed on to any
            user-defined recovery/optionality logic.
        prev_grid_values: Grid values at *t + dt* (shape ``(N,)``) **after**
            any dividend and cash-flow adjustments.
        survival_probabilities: Element-wise default-free survival
            probabilities over the interval ``(t, t+dt]`` (same shape as *S*).
        tridiag_matrix_entries: Mapping with keys ``"sub"``, ``"diag"``,
            ``"super"`` containing the three 1-D bands of the implicit matrix
            (lengths *N-1*, *N*, and *N-1* respectively).
        instrument: Financial instrument associated with this grid layer.
            If supplied, it may expose
              • ``recovery_fcn(v, S, t, discount_factor_fcn)``
              • ``optionality_fcn(v, S, t, discount_factor_fcn)``
            where *v* is an array of **undiscounted** prices.
        dividends: Data-frame of discrete dividends; forwarded unchanged to
            any instrument-specific logic (optional).
        instr_name: Human-readable label used only in log messages.

    Returns:
        NDArray[Any]: Grid values at time *t* (same shape as `prev_grid_values`).

    Raises:
        RuntimeError: If the LAPACK tridiagonal solver (`dgtsv`) signals a
            failure (non-zero ``info`` code).

    Notes:
        1. Grid values passed in and returned are *discounted* by
           `full_discount_factor`, exactly mirroring the change of variables
           used in the original R implementation.
        2. Negative prices are disallowed: any negative component produced by
           the linear solve is floored to zero before subsequent processing.
    """
    sub = tridiag_matrix_entries["sub"].copy()
    diag = tridiag_matrix_entries["diag"].copy()
    sup = tridiag_matrix_entries["super"].copy()

    # Solve Ax = b using LAPACK DGTSV (Gaussian elimination with pivoting).
    _, _, _, hold_cond_on_surv, info = dgtsv(sub, diag, sup, prev_grid_values.copy())
    if info != 0:
        raise RuntimeError(f"LAPACK dgtsv failed with info={info}")

    # No negative values allowed for derivative
    hold_cond_on_surv = np.maximum(hold_cond_on_surv, 0.0)

    # ------------------------------------------------------------------ #
    # Default recovery (if any)
    # ------------------------------------------------------------------ #
    if instrument is None or getattr(instrument, "recovery_fcn", None) is None:
        recovery_values = np.zeros_like(S)
    else:
        recovery_at_t = instrument.recovery_fcn(
            v=hold_cond_on_surv / full_discount_factor,
            S=S,
            t=t,
            discount_factor_fcn=discount_factor_fcn,
        )
        recovery_values = full_discount_factor * recovery_at_t

    # ------------------------------------------------------------------ #
    # Combine survival and default legs
    # ------------------------------------------------------------------ #
    survival_value = survival_probabilities * hold_cond_on_surv
    default_value = (
        (1.0 - survival_probabilities) * local_discount_factor * recovery_values
    )
    hold_value = survival_value + default_value

    logger_step.info(
        f"{instr_name}: t={t:.6g}, ⟨hold⟩={np.mean(hold_cond_on_surv):.6g}, "
        f"⟨recovery⟩={np.mean(recovery_values):.6g}, "
        f"⟨survival P⟩={np.mean(survival_probabilities):.6g}, "
        f"⟨combined⟩={np.mean(hold_value):.6g}"
    )

    # ------------------------------------------------------------------ #
    # Optionality (callability, conversion, etc.)
    # ------------------------------------------------------------------ #
    if instrument is None or getattr(instrument, "optionality_fcn", None) is None:
        new_value = hold_value
    else:
        undiscounted_value = instrument.optionality_fcn(
            hold_value / full_discount_factor,
            S,
            t,
            discount_factor_fcn=discount_factor_fcn,
        )
        new_value = full_discount_factor * undiscounted_value

    return new_value


def timestep_instruments(
    z: NDArray[Any],
    prev_grid_values: NDArray[Any],
    t: float,
    dt: float,
    S0: float,
    instruments: Mapping[str, PricedInstrument] | Sequence[PricedInstrument],
    stock_level_fcn: Callable[[NDArray[Any], float], NDArray[Any]],
    discount_factor_fcn: DiscountFactorFcnType,
    default_intensity_fcn: TermStructFcnType,
    variance_cumulation_fcn: TermStructFcnType,
    dividends: pd.DataFrame | None = None,
) -> NDArray[Any]:
    """Step one implicit layer backward for a single instrument.

    The routine solves the tridiagonal linear system that arises from an
    θ-scheme with θ = 1 (fully implicit) and then combines survival and
    default-recovery legs to obtain the ex-default value at time *t*.

    Args:
        t: Valuation time **after** the step has been taken – i.e. the solver
            moves from *t + dt* back to *t*.
        S: Stock-price grid (length *N*), obtained from the space grid *z*
            through the supplied `stock_level_fcn` in the caller.
        full_discount_factor: Discount factor from time *0* to *t*
            ``DF(t, 0)``.  Used to map between discounted grid values and
            outright prices.
        local_discount_factor: Discount factor from *t* to *t + dt*
            ``DF(t+dt, t)``.  Appears in the default-recovery leg.
        discount_factor_fcn: Callable ``DF(T, t)`` that returns the price at
            time *t* of one monetary unit payable at *T*.  Passed on to any
            user-defined recovery/optionality logic.
        prev_grid_values: Grid values at *t + dt* (shape ``(N,)``) **after**
            any dividend and cash-flow adjustments.
        survival_probabilities: Element-wise default-free survival
            probabilities over the interval ``(t, t+dt]`` (same shape as *S*).
        tridiag_matrix_entries: Mapping with keys ``"sub"``, ``"diag"``,
            ``"super"`` containing the three 1-D bands of the implicit matrix
            (lengths *N-1*, *N*, and *N-1* respectively).
        instrument: Financial instrument associated with this grid layer.
            If supplied, it may expose
              • ``recovery_fcn(v, S, t, discount_factor_fctn)``
              • ``optionality_fcn(v, S, t, discount_factor_fctn)``
            where *v* is an array of **undiscounted** prices.
        dividends: Data-frame of discrete dividends; forwarded unchanged to
            any instrument-specific logic (optional).
        instr_name: Human-readable label used only in log messages.

    Returns:
        NDArray[Any]: Grid values at time *t* (same shape as `prev_grid_values`).

    Raises:
        RuntimeError: If the LAPACK tridiagonal solver (`dgtsv`) signals a
            failure (non-zero ``info`` code).

    Notes:
        1. Grid values passed in and returned are *discounted* by
           `full_discount_factor`, exactly mirroring the change of variables
           used in the original R implementation.
        2. Negative prices are disallowed: any negative component produced by
           the linear solve is floored to zero before subsequent processing.
    """
    full_df = discount_factor_fcn(t, 0.0)
    prev_ts_df = discount_factor_fcn(t + dt, 0.0)
    local_df = discount_factor_fcn(t + dt, t)
    r = -math.log(local_df) / dt

    S = stock_level_fcn(z, t)
    h = default_intensity_fcn(t, S)
    if h.shape != S.shape:
        raise ValueError("default_intensity_fcn must return an array same shape as S")

    sigma = math.sqrt(variance_cumulation_fcn(t + dt, t) / dt)

    # Dividend adjustment across **all** layers
    div_adj_grid = adjust_for_dividends(
        prev_grid_values.copy(), t, dt, r, h, S, S0, dividends=dividends
    )

    surv_prob = np.exp(-h * dt)

    logger_step.info(
        f"t={t:.6g}: ⟨h⟩={np.mean(h):.6g}, ⟨r⟩={r:.6g}, "
        f"sigma={sigma:.6g}, surv P∈[{np.min(surv_prob):.6g}, {np.max(surv_prob):.6g}] "
        f"⟨surv P⟩={np.mean(surv_prob):.6g}"
    )

    dz = np.diff(z)[0]  # regular grid assumed
    structure_constant = dt / dz**2
    logger_step.info(
        f"t={t:.6g}: dt={dt:.6g}, dz={dz:.6g}, structure const={structure_constant:.6g}"
    )

    matrix_entries = construct_tridiagonals(
        sigma, structure_constant, drift=h * dt / dz
    )

    # Normalise `instruments` into an iterable of (name, obj)
    instr_iter: Iterable[tuple[str, PricedInstrument]]
    if isinstance(instruments, Mapping):
        instr_iter = instruments.items()
    else:
        instr_iter = [(f"layer_{k}", inst) for (k, inst) in enumerate(instruments)]

    for k, (instr_name, instrument) in enumerate(instr_iter):
        prev_layer_vals = div_adj_grid[:, k]

        if instrument.maturity < t:
            logger_step.info(
                f"{instr_name}: maturity={instrument.maturity} < t={t}; layer skipped."
            )
            div_adj_grid[:, k] = np.full_like(prev_layer_vals, np.nan)
            continue

        # Layer may be entirely NA first time round
        if np.isnan(prev_layer_vals).all():
            div_adj_grid[:, k] = full_df * instrument.optionality_fcn(
                np.array([0.0]), S, t
            )
            continue

        logger_step.info(
            f"{instr_name}: stepping from {t+dt} → {t} on N={len(z)} nodes; "
            f"⟨V_prev⟩={np.mean(prev_layer_vals) / (full_df * local_df):.6g}"
        )

        # Optional cash-flow updates
        if hasattr(instrument, "update_cashflows"):
            cash_inc = instrument.update_cashflows(
                t, t + dt, discount_factor_fcn=discount_factor_fcn
            )
            grid_inc = cash_inc * prev_ts_df
            logger_step.info(
                f"{instr_name}: cash-flows in ({t}, {t+dt}] "
                f"max Δ={np.max(grid_inc):.6g}, applying to grid."
            )
            prev_layer_vals = prev_layer_vals + grid_inc

        div_adj_grid[:, k] = take_implicit_timestep(
            t=t,
            S=S,
            full_discount_factor=full_df,
            local_discount_factor=local_df,
            discount_factor_fcn=discount_factor_fcn,
            prev_grid_values=prev_layer_vals,
            survival_probabilities=surv_prob,
            tridiag_matrix_entries=matrix_entries,
            instrument=instrument,
            dividends=dividends,
            instr_name=instr_name,
        )

        logger_step.info(
            f"{instr_name}: completed step; ⟨V_new⟩="
            f"{np.mean(div_adj_grid[:, k]) / full_df:.6g}"
        )

    return div_adj_grid


def infer_conforming_time_grid(
    min_num_time_steps: int,
    Tmax: float,
    instruments: (
        Mapping[str, PricedInstrument] | Sequence[PricedInstrument] | None
    ) = None,
) -> NDArray[Any]:
    """Return a 1-D array of time nodes **ascending** from 0 to *Tmax*.

    The algorithm starts with an equidistant grid of ``min_num_time_steps``
    intervals, then inserts *critical times* (coupon dates, call/put windows,
    etc.) supplied by each instrument.

    Args:
        min_num_time_steps: Minimum number of steps *between* 0 and *Tmax*.
        Tmax: Final time on the grid.
        instruments: Either a mapping ``{name: instrument}`` or an iterable of
            instruments.  Each object may expose a ``critical_times()`` method
            that returns a 1-D iterable of additional times to include.

    Returns:
        NDArray[Any]: Sorted array of unique time nodes in ``[0, Tmax]``.
    """
    # ------------------------------------------------------------------ #
    # Base equally spaced grid
    # ------------------------------------------------------------------ #
    time_grid = np.linspace(0.0, Tmax, num=min_num_time_steps + 1)

    # ------------------------------------------------------------------ #
    # Insert instrument-specific dates
    # ------------------------------------------------------------------ #
    if instruments:
        instr_items = (
            instruments.items()
            if isinstance(instruments, Mapping)
            else enumerate(instruments)
        )
        for key, instr in instr_items:
            name = key if isinstance(key, str) else f"layer_{key}"
            time_grid = np.append(time_grid, getattr(instr, "maturity", np.nan))

            logger_setup.info(
                f"Inspecting instrument {name} (maturity={getattr(instr, 'maturity', 'N/A')}) "
                "for critical timetable entries."
            )

            if hasattr(instr, "critical_times"):
                crit = np.asarray(instr.critical_times(), dtype=float)
                time_grid = np.append(time_grid, crit)
                logger_setup.info(
                    f"Instrument {name} added critical times {crit.tolist()} to grid."
                )
            else:
                logger_setup.info(f"Instrument {name} exposes no critical_times().")

    # ------------------------------------------------------------------ #
    # Deduplicate & clamp to [0, Tmax]
    # ------------------------------------------------------------------ #
    time_grid = np.unique(time_grid[(time_grid >= 0.0) & (time_grid <= Tmax)])

    # Merge nearly-identical times (floating-point noise)
    rounded = np.unique(np.round(time_grid, TIME_RESOLUTION_SIGNIF_DIGITS))
    if rounded.size < time_grid.size:
        inner = np.unique(
            np.round(
                time_grid[(time_grid > 0.0) & (time_grid < Tmax)],
                TIME_RESOLUTION_SIGNIF_DIGITS,
            )
        )
        time_grid = np.unique(np.concatenate(([0.0], inner, [Tmax])))
        logger_setup.info(
            f"Collapsed {time_grid.size - 2 - inner.size} nearly coincident "
            "time points into a cleaner grid."
        )

    logger_setup.info(
        f"Base grid had {min_num_time_steps} steps; final grid has "
        f"{time_grid.size - 1} steps up to t={time_grid[-1]}."
    )
    return np.sort(time_grid)


# ---------------------------------------------------------------------------
# B.  Iterate over existing time points
# ---------------------------------------------------------------------------


def iterate_grid_from_timestep(
    starting_time_step: int,
    time_pts: NDArray[Any],
    z: NDArray[Any],
    S0: float,
    instruments: Mapping[str, PricedInstrument] | Sequence[PricedInstrument],
    *,
    stock_level_fcn: Callable[[NDArray[Any], float], NDArray[Any]],
    discount_factor_fcn: DiscountFactorFcnType,
    default_intensity_fcn: TermStructFcnType,
    variance_cumulation_fcn: TermStructFcnType,
    dividends: pd.DataFrame | None = None,
    grid: NDArray[Any] | None = None,
    original_grid_values: NDArray[Any] | None = None,
) -> NDArray[Any]:
    """Backward-step through the time mesh.

    Using time steps `starting_time_step` down to zero, iterate implicitly.

    Args:
        starting_time_step: Index *m* such that the iteration will execute
            steps ``m, m-1, …, 1`` (Python 0-based indexing).
        time_pts: Full array of time nodes produced by
            :pyfunc:`infer_conforming_time_grid`.
        z: Spatial grid (length *N*).
        S0: Spot equity price at time zero (needed for dividend logic).
        instruments: Sequence or mapping of instrument objects, coerced the
            same way as in :pyfunc:`timestep_instruments`.
        stock_level_fcn, discount_factor_fcn, default_intensity_fcn,
        variance_cumulation_fcn: Model callbacks, see
            :pyfunc:`timestep_instruments`.
        dividends: Optional discrete dividend schedule.
        grid: Pre-allocated 3-D array shaped
            ``(len(time_pts), len(z), n_instr)`` into which results are written.
            If ``None`` only the final slice is returned.
        original_grid_values: The matrix slice located at the end of
            `starting_time_step` (shape ``(N, L)``).  If ``None`` this is
            obtained from `grid` if supplied.

    Returns:
        NDArray[Any]: Either the fully populated `grid` or the matrix of
        values at *t = time_pts[0]* (depending on whether `grid` was provided).

    Raises:
        ValueError: If shapes are inconsistent.
    """
    if original_grid_values is None:
        if grid is None:
            raise ValueError("original_grid_values must be supplied when grid is None.")
        original_grid_values = grid[starting_time_step, :, :]

    prev_vals = original_grid_values

    for m in range(starting_time_step - 1, -1, -1):  # inclusive countdown
        t = time_pts[m]
        dt = time_pts[m + 1] - time_pts[m]

        logger_iter.info(f"Stepping layer m={m} from t={t+dt} → t={t} (dt={dt}).")

        new_vals = timestep_instruments(
            z,
            prev_vals,
            t,
            dt,
            S0,
            instruments,
            stock_level_fcn=stock_level_fcn,
            discount_factor_fcn=discount_factor_fcn,
            default_intensity_fcn=default_intensity_fcn,
            variance_cumulation_fcn=variance_cumulation_fcn,
            dividends=dividends,
        )

        if grid is not None:
            grid[m, :, :] = new_vals

        prev_vals = new_vals

    return grid if grid is not None else prev_vals


def integrate_pde(
    z: NDArray[Any],  # (N,)
    min_num_time_steps: int,
    S0: float,
    Tmax: float,
    instruments: Mapping[str, PricedInstrument] | Sequence[PricedInstrument],  # (L,)
    *,
    stock_level_fcn: Callable[[NDArray[Any], float], NDArray[Any]],
    discount_factor_fcn: DiscountFactorFcnType,
    default_intensity_fcn: TermStructFcnType,
    variance_cumulation_fcn: TermStructFcnType,
    dividends: pd.DataFrame | None = None,
) -> NDArray[Any]:
    """Finite–difference valuation of a portfolio of instruments.

    The routine creates a **time × space × instrument** grid of *discounted*
    prices and backward-propagates it from *Tmax* to 0 using an implicit
    solver.  The returned tensor is suitable for:

    • obtaining present values (slice ``grid[0, :]``),
    • extracting intermediate values for calibration / Greeks, or
    • seeding subsequent, path-dependent calculations.

    Parameters
    ----------
    z
        Regular spatial grid in log-price (*z*) space
        of shape ``(N,)``.  Grid spacing must be uniform.
    min_num_time_steps
        Baseline number of equal-width time intervals.  Additional nodes
        originating from coupon, call/put and other contractual dates will be
        inserted automatically.
    S0
        Spot equity price at time 0 (only required by the dividend logic).
    Tmax
        Final time horizon (years) at which terminal pay-offs are defined.
    instruments
        Either a mapping ``{name: instrument}`` **or** an ordered
        sequence of instrument objects.  Each object must satisfy the
        ``PricedInstrument`` protocol, i.e. expose at least:

        • ``maturity`` (float)
        • ``terminal_values(v, S, t, discount_factor_fctn)`` → ``ndarray``
        • ``optionality_fcn(v, S, t, discount_factor_fctn)`` → ``ndarray``

        Optional helpers such as ``critical_times`` and
        ``update_cashflows`` will be honoured if present.
    stock_level_fcn
        Callable ``S = stock_level_fcn(z, t)`` that converts a *z*-location and
        time into a spot price.
    discount_factor_fcn
        Discount curve ``DF(T, t)`` returning the time-*t* price of 1 unit paid
        at *T*.  May return either a float or an array broadcastable to *S*.
    default_intensity_fcn
        Short default intensity λ(*t*, *S*) returning an array of shape
        ``(N,)`` for every evaluation.
    variance_cumulation_fcn
        Total variance between two times,
        e.g. ``sigma**2 * (T - t)`` for constant volatility; used to compute the
        local σ in each time slab.
    dividends
        Data-frame with columns ``time``, ``fixed``, ``proportional`` describing
        discrete dividends of the underlying equity (optional).

    Returns
    -------
    NDArray[Any]
        A 3-D tensor ``grid[t_index, z_index, instrument_index]`` of discounted
        prices.  Element ``grid[0, j, k]`` is the present value at time 0 for
        node *j* (stock level ``S[j]``) and instrument *k*.

    Raises
    ------
    RuntimeError
        If an instrument’s ``terminal_values`` contains NaNs or if the PDE
        solver fails internally.
    ValueError
        If user-supplied callback functions return arrays with shapes that are
        incompatible with the spatial grid.
    """
    # ------------------------------------------------------------------ #
    # 1. Build the joint time grid
    # ------------------------------------------------------------------ #
    time_pts = infer_conforming_time_grid(
        min_num_time_steps, Tmax, instruments=instruments
    )
    n_t, n_z = time_pts.size, z.size
    n_instr = len(instruments)

    # 2. Allocate (t, z, instr) tensor for discounted values
    grid: NDArray[Any] = np.full((n_t, n_z, n_instr), np.nan)

    # 3. Populate terminal slice
    S_T = stock_level_fcn(z, Tmax)
    df_T = discount_factor_fcn(Tmax, 0.0)

    instr_items = (
        instruments.items()
        if isinstance(instruments, Mapping)
        else enumerate(instruments)
    )
    for k, (name, instr) in enumerate(instr_items):
        if instr.maturity < Tmax:
            continue  # already NaN initialised
        undisc = instr.terminal_values(
            np.zeros_like(S_T),
            S=S_T,
            t=instr.maturity,
            discount_factor_fcn=discount_factor_fcn,
        )
        if np.isnan(undisc).any():
            raise RuntimeError(f"Instrument {name} produced NaN terminal values")
        grid[-1, :, k] = df_T * undisc
        instr.last_computed_grid = np.full_like(S_T, np.nan)

    # 4. Backwardate to t = 0
    grid = iterate_grid_from_timestep(
        n_t - 1,
        time_pts,
        z,
        S0,
        instruments,
        stock_level_fcn=stock_level_fcn,
        discount_factor_fcn=discount_factor_fcn,
        default_intensity_fcn=default_intensity_fcn,
        variance_cumulation_fcn=variance_cumulation_fcn,
        dividends=dividends,
        grid=grid,
    )

    return grid


def form_present_value_grid(
    S0: float,
    num_time_steps: int,
    instruments: Mapping[str, PricedInstrument] | Sequence[PricedInstrument],
    *,
    const_volatility: float = 0.5,
    const_short_rate: float = 0.0,
    const_default_intensity: float = 0.0,
    override_Tmax: float | None = None,
    discount_factor_fcn: DiscountFactorFcnType | None = None,
    default_intensity_fcn: TermStructFcnType | None = None,
    variance_cumulation_fcn: TermStructFcnType | None = None,
    dividends: pd.DataFrame | None = None,
    borrow_cost: float = 0.0,
    dividend_rate: float = 0.0,
    structure_constant: float = 2.0,
    std_devs_width: float = 3.0,
    grid_center: float | None = None,
) -> pd.DataFrame:
    """Build a discounted present-value grid for *all* instruments.

    Parameters
    ----------
    S0
        Current spot price of the underlying equity.
    num_time_steps
        Minimum number of time steps in the finite-difference grid.
    instruments
        Mapping or sequence of instrument objects complying with the
        `PricedInstrument` protocol.
    const_volatility, const_short_rate, const_default_intensity
        Constant parameters used *only if* the corresponding model callbacks
        are *not* supplied.
    override_Tmax
        If given, forces the PDE integration to use this horizon instead of
        the maximum instrument maturity.
    discount_factor_fcn
        Callable ``DF(T, t)``; if ``None`` defaults to
        ``exp(−const_short_rate × (T − t))``.
    default_intensity_fcn
        Callable ``h(t, S)``; if ``None`` returns the constant
        ``const_default_intensity``.
    variance_cumulation_fcn
        Callable ``Var(T, t)``; if ``None`` returns
        ``const_volatility² × (T − t)``.
    dividends
        Optional discrete dividend schedule.
    borrow_cost, dividend_rate
        Continuous rates that enter the drift ``c = r − q − borrow_cost``.
    structure_constant, std_devs_width
        Grid parameters passed on to
        :pyfunc:`ragtopy.implicit.grid.construct_implicit_grid_structure`.
    grid_center
        Optional override for the grid’s *K* (centre) value – useful for
        scenarios without a natural strike.

    Returns
    -------
    pandas.DataFrame
        Columns = instruments + ``"Underlying"`` ;
        Rows    = spatial nodes (same order as `grid_structure["z"]`).
    """
    # ------------------------------------------------------------------ #
    # Normalise instrument container
    # ------------------------------------------------------------------ #
    if isinstance(instruments, Mapping):
        instr_items = list(instruments.items())
    else:
        instr_items = [
            (getattr(inst, "name", f"inst_{k}"), inst)
            for k, inst in enumerate(instruments)
        ]
        instruments = {name: inst for name, inst in instr_items}

    # ------------------------------------------------------------------ #
    # Determine K (grid centre) and Tmax
    # ------------------------------------------------------------------ #
    K = S0
    Tmax = 0.0 if override_Tmax is None else override_Tmax

    for name, inst in instr_items:
        if hasattr(inst, "strike") and inst.strike > 0:
            K = inst.strike
        if override_Tmax is None and inst.maturity > Tmax:
            Tmax = inst.maturity
        logger_pv.info(f"Instrument {name}: maturity={inst.maturity}.")

    if grid_center is not None:
        K = grid_center
        logger_pv.info(f"Grid centre overridden: K={K}.")

    if Tmax <= 0:
        raise ValueError(
            "All instrument maturities are non-positive; nothing to price."
        )

    # ------------------------------------------------------------------ #
    # Default model callbacks (if absent)
    # ------------------------------------------------------------------ #
    if discount_factor_fcn is None:
        discount_factor_fcn = cast(  # noqa: E731
            DiscountFactorFcnType,
            lambda T, t, r=const_short_rate: np.exp(-r * (T - t)),
        )  # noqa: E731
    if default_intensity_fcn is None:
        default_intensity_fcn = cast(  # noqa: E731
            TermStructFcnType, lambda t, S, h0=const_default_intensity: h0 + 0.0 * S
        )  # noqa: E731
    if variance_cumulation_fcn is None:
        variance_cumulation_fcn = cast(
            TermStructFcnType, lambda T, t, sig=const_volatility: sig**2 * (T - t)
        )  # noqa: E731  # noqa: E731

    # ------------------------------------------------------------------ #
    # Grid design – equivalent constant σ and r
    # ------------------------------------------------------------------ #
    sigma = math.sqrt(variance_cumulation_fcn(Tmax, 0.0) / Tmax)
    r = -math.log(discount_factor_fcn(Tmax, 0.0)) / Tmax
    c = r - dividend_rate - borrow_cost
    logger_pv.info(f"Equivalent σ={sigma:.4g}, r={r:.4g} ⇒ drift c={c:.4g}.")

    # Build spatial/time grid
    grid_structure = construct_implicit_grid_structure(
        tenors=[Tmax],
        M=num_time_steps,
        S0=S0,
        K=K,
        c=c,
        sigma=sigma,
        structure_constant=structure_constant,
        std_devs_width=std_devs_width,
    )

    def stock_level_fcn(z: NDArray[Any], t: float) -> NDArray[Any]:
        S_levels = K * np.exp(z - (c - 0.5 * sigma**2) * (Tmax - t))
        logger_pv.debug(
            f"Stock levels @t={t}: min={np.min(S_levels):.4g} "
            f"max={np.max(S_levels):.4g} (N={S_levels.size})."
        )
        return S_levels

    # ------------------------------------------------------------------ #
    # PDE integration
    # ------------------------------------------------------------------ #
    grid = integrate_pde(
        z=grid_structure["z"],
        min_num_time_steps=num_time_steps,
        S0=S0,
        Tmax=Tmax,
        instruments=instruments,
        stock_level_fcn=stock_level_fcn,
        discount_factor_fcn=discount_factor_fcn,
        default_intensity_fcn=default_intensity_fcn,
        variance_cumulation_fcn=variance_cumulation_fcn,
        dividends=dividends,
    )
    logger_pv.info("Completed PDE integration.")

    # ------------------------------------------------------------------ #
    # Assemble DataFrame with instrument + underlying columns
    # ------------------------------------------------------------------ #
    pv_0 = grid[0, :, :]  # slice t=0
    data_cols = {name: pv_0[:, idx] for idx, (name, _) in enumerate(instr_items)}
    data_cols["Underlying"] = stock_level_fcn(grid_structure["z"], 0.0)

    present_value_df = pd.DataFrame(data_cols, index=grid_structure["z"])
    return present_value_df


def find_present_value(
    S0: float,
    num_time_steps: int,
    instruments: Mapping[str, Any] | Sequence[Any],
    *,
    const_volatility: float = 0.5,
    const_short_rate: float = 0.0,
    const_default_intensity: float = 0.0,
    override_Tmax: float | None = None,
    discount_factor_fcn: TermStructFcnType | None = None,
    default_intensity_fcn: TermStructFcnType | None = None,
    variance_cumulation_fcn: TermStructFcnType | None = None,
    dividends: pd.DataFrame | None = None,
    borrow_cost: float = 0.0,
    dividend_rate: float = 0.0,
    structure_constant: float = 2.0,
    std_devs_width: float = 3.0,
) -> dict[str, float]:
    """Use a model to estimate the present value of financial derivatives.

    Use a finite difference scheme to form estimates of present values for a variety
    of stock prices. Once the grid has been created, interpolate to obtain the
    value of each instrument at the present stock price S0.

    Args:
        S0: Current stock price
        num_time_steps: Number of time steps for the grid
        instruments: Collection of financial instruments to price
        const_volatility: Constant volatility parameter
        const_short_rate: Constant short rate
        const_default_intensity: Constant default intensity
        override_Tmax: Override maximum time if specified
        discount_factor_fcn: Function for discount factors
        default_intensity_fcn: Function for default intensity
        variance_cumulation_fcn: Function for variance cumulation
        dividends: DataFrame of dividend information
        borrow_cost: Cost of borrowing
        dividend_rate: Dividend rate
        structure_constant: Structure constant for grid construction
        std_devs_width: Width in standard deviations for grid

    Returns:
        Dictionary of present values with instrument names as keys

    Note:
        This function inherits parameters from form_present_value_grid and
        construct_implicit_grid_structure. See those functions for additional
        parameter details.
    """
    # Handle dividends description for logging
    if dividends is None:
        divs_descr = "None"
    else:
        divs_descr = str(len(dividends))

    logger_pv.info(
        f"find_present_value(S0={S0}, num_time_steps={num_time_steps}, "
        f"<{len(instruments)} instruments>, <divs: {divs_descr}>, "
        f"structure_constant={structure_constant}, std_devs_width={std_devs_width})"
    )

    # Handle instrument naming - convert to dict if needed
    if isinstance(instruments, Sequence):
        # Convert sequence to dict, using instrument names or indices
        instrument_dict = {}
        for i, instrument in enumerate(instruments):
            if hasattr(instrument, "name") and instrument.name:
                instrument_dict[instrument.name] = instrument
            else:
                instrument_dict[str(i + 1)] = instrument
        instruments = instrument_dict
    elif not isinstance(instruments, Mapping):
        raise TypeError("instruments must be a Mapping or Sequence")

    # Ensure all instruments have names
    named_instruments = {}
    unnamed_count = 1
    for key, instrument in instruments.items():
        if key:
            named_instruments[key] = instrument
        else:
            named_instruments[str(unnamed_count)] = instrument
            unnamed_count += 1

    # Form the present value grid
    present_value_grid = form_present_value_grid(
        S0=S0,
        num_time_steps=num_time_steps,
        instruments=named_instruments,
        const_volatility=const_volatility,
        const_short_rate=const_short_rate,
        const_default_intensity=const_default_intensity,
        override_Tmax=override_Tmax,
        discount_factor_fcn=discount_factor_fcn,
        default_intensity_fcn=default_intensity_fcn,
        variance_cumulation_fcn=variance_cumulation_fcn,
        dividends=dividends,
        borrow_cost=borrow_cost,
        dividend_rate=dividend_rate,
        structure_constant=structure_constant,
        std_devs_width=std_devs_width,
    )

    # Interpolate present values at S0 using spline interpolation
    # with linear extrapolation to match R's stats::spline behavior
    # and Neumann boundary conditions
    present_values = {}
    for instr_name in named_instruments.keys():
        if (
            "Underlying" in present_value_grid.columns
            and instr_name in present_value_grid.columns
        ):
            pv_interpolation = spline_extrapolate(
                np.array(present_value_grid["Underlying"].values),
                np.array(present_value_grid[instr_name].values),
                np.array([S0], dtype=float),
            )
            present_values[instr_name] = float(pv_interpolation[0])
        else:
            logger_pv.warning(
                f"Could not find data for instrument '{instr_name}' or 'Underlying' "
                f"column in present_value_grid"
            )
    return present_values
