import logging
from typing import Any
from typing import Optional

import numpy as np
from numpy.typing import NDArray
from scipy.interpolate import make_interp_spline


logger = logging.getLogger(f"{__name__}")


def spline_extrapolate(
    x: NDArray[Any],
    y: NDArray[Any],
    x_new: NDArray[Any],
    output_y: Optional[NDArray[Any]] = None,
) -> NDArray[Any]:
    """
    Perform natural spline interpolation with linear extrapolation beyond boundaries.

    This function creates a natural (cubic) spline through the given data points
    and evaluates it at new x coordinates. For points outside the original x range,
    linear extrapolation is performed using the derivative at the boundary points.

    Args:
        x: Array of x-coordinates of data points (must be strictly increasing)
        y: Array of y-coordinates of data points (same length as x)
        x_new: Array of x-coordinates where interpolation is desired
        output_y: Optional pre-allocated output array. If None, a new array is created

    Returns:
        Array of interpolated/extrapolated y-values at x_new coordinates

    Raises:
        ValueError: If x and y have different lengths or if x is not strictly increasing

    Example:
        >>> x = np.array([1, 2, 3, 4, 5])
        >>> y = np.array([1, 4, 9, 16, 25])
        >>> x_new = np.array([0, 1.5, 3, 4.5, 6])
        >>> result = spline_extrapolate(x, y, x_new)
    """
    logger.debug(f"Interpolating {len(x)} points to {len(x_new)} new points")

    # Input validation
    if len(x) != len(y):
        raise ValueError(f"x and y must have same length, got {len(x)} and {len(y)}")

    if len(x) < 2:
        raise ValueError(f"Need at least 2 points for interpolation, got {len(x)}")

    if not np.all(np.diff(x) > 0):
        raise ValueError("x values must be strictly increasing")

    # Prepare output array
    if output_y is None:
        output_y = np.empty_like(x_new, dtype=np.float64)
    elif len(output_y) != len(x_new):
        raise ValueError(
            f"output_y length {len(output_y)} must match x_new length {len(x_new)}"
        )

    # Create natural spline (bc_type='natural' sets second derivatives to zero at boundaries)
    spline = make_interp_spline(x, y, k=3, bc_type="natural")

    # Define boundary points
    lower_bound, upper_bound = x[0], x[-1]

    # Identify points inside and outside the interpolation range
    is_inside = (x_new >= lower_bound) & (x_new <= upper_bound)
    is_below = x_new < lower_bound
    is_above = x_new > upper_bound

    logger.debug(
        f"Points: {np.sum(is_inside)} inside, {np.sum(is_below)} below, {np.sum(is_above)} above"
    )

    # 1. Interpolate for points inside the original range
    if np.any(is_inside):
        output_y[is_inside] = spline(x_new[is_inside])

    # 2. Linearly extrapolate for points below the range
    if np.any(is_below):
        # Get slope (1st derivative) at the lower boundary
        m_lower = spline.derivative(nu=1)(lower_bound)
        y_lower = spline(lower_bound)
        # Point-slope formula: y = y0 + m * (x - x0)
        output_y[is_below] = y_lower + m_lower * (x_new[is_below] - lower_bound)
        logger.debug(f"Lower extrapolation: slope={m_lower:.6f}, y0={y_lower:.6f}")

    # 3. Linearly extrapolate for points above the range
    if np.any(is_above):
        # Get slope (1st derivative) at the upper boundary
        m_upper = spline.derivative(nu=1)(upper_bound)
        y_upper = spline(upper_bound)
        # Point-slope formula: y = y0 + m * (x - x0)
        output_y[is_above] = y_upper + m_upper * (x_new[is_above] - upper_bound)
        logger.debug(f"Upper extrapolation: slope={m_upper:.6f}, y0={y_upper:.6f}")

    return output_y
