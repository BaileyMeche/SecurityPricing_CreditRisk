from __future__ import annotations

import logging
import math
from typing import Any
from typing import Union
from typing import cast

import numpy as np
import pandas as pd
from numpy.typing import NDArray

from .blackscholes import black_scholes
from .blackscholes import black_scholes_on_term_structures
from .instruments import PUT
from .term_structures import DiscountFactorFcnType
from .term_structures import TermStructFcnType


logger_iv = logging.getLogger(f"{__name__}.implied_volatility")
logger_eq = logging.getLogger(f"{__name__}.equivalent_bs_vola_to_jump")

_ArrayLike = Union[float, NDArray[Any]]


# ---------------------------------------------------------------------------
# 1.  Scalar implied volatility (Newton + bisection safeguard)
# ---------------------------------------------------------------------------


def implied_volatility(
    option_price: float,
    callput: int,
    S0: float,
    K: float,
    r: float,
    time: float,
    *,
    const_default_intensity: float = 0.0,
    divrate: float = 0.0,
    borrow_cost: float = 0.0,
    dividends: pd.DataFrame | None = None,
    relative_tolerance: float = 1e-6,
    max_iter: int = 100,
    max_vola: float = 4.0,
) -> float:
    """Black–Scholes (or Merton) implied volatility via damped Newton.

    Parameters
    ----------
    option_price
        Observed option PV.
    callput
        ``CALL`` (+1) or ``PUT`` (−1).
    S0, K, r, time
        Usual Black–Scholes inputs.
    const_default_intensity
        Jump-to-default hazard λ (set to 0 for plain BS).
    divrate
        Continuous dividend yield *q*.
    borrow_cost
        Continuous stock-borrow cost.
    dividends
        Optional discrete dividend schedule
        (see :func:`ragtopy.blackscholes.black_scholes`).
    relative_tolerance
        Stop when ``|model − market| / market`` ≤ *tol*.
    max_iter
        Maximum Newton iterations.  Each iteration may fall back to a
        bisection step to guarantee bracketing.
    max_vola
        Upper bound for σ in the root search.

    Returns
    -------
    float
        Implied volatility, or ``math.nan`` if no solution in *(0, max_vola]*.

    Examples
    --------
    Basic Black–Scholes call::

        >>> from ragtop.calibration import implied_volatility
        >>> from ragtop.instruments import CALL, PUT
        >>> iv = implied_volatility(
        ...     option_price=2.50,
        ...     callput=CALL,
        ...     S0=100.0, K=105.0,
        ...     r=0.01,
        ...     time=0.75
        ... )
        >>> round(iv, 4)
        0.1214

    Put with a jump-to-default hazard (λ = 7 %)::

        >>> iv = implied_volatility(
        ...     option_price=17.00,
        ...     callput=PUT,
        ...     S0=250.0, K=245.0,
        ...     r=0.005,
        ...     time=2.0,
        ...     const_default_intensity=0.03
        ... )
        >>> round(iv,4)
        0.076

    Call that includes a discrete and proportional cash dividend::

        >>> import pandas as pd
        >>> divs = pd.DataFrame(
        ...     {"time": [0.4], "fixed": [1.12], "proportional": [0.01]}
        ... )
        >>> iv = implied_volatility(
        ...     option_price=8.10,
        ...     callput=CALL,
        ...     S0=90.0, K=85.0,
        ...     r=0.02, time=1.0,
        ...     dividends=divs
        ... )
        >>> round(iv,4)
        0.1404
    """
    min_vola = 1e-12

    def _price_vega(vol: float) -> tuple[float, float]:
        out = black_scholes(
            callput,
            S0,
            K,
            r,
            time,
            vola=vol,
            default_intensity=const_default_intensity,
            divrate=divrate,
            borrow_cost=borrow_cost,
            dividends=dividends,
        )
        return float(out["Price"]), float(out["Vega"])

    price_min, _ = _price_vega(min_vola)
    price_max, _ = _price_vega(max_vola)

    # Sanity checks on bracketing interval
    if option_price < price_min - 1e-12:
        logger_iv.warning(
            "Price %.6g below zero-vol minimum %.6g – no positive IV.",
            option_price,
            price_min,
        )
        return math.nan
    if option_price > price_max + 1e-12:
        logger_iv.warning(
            "Price %.6g above σ=%.2f maximum %.6g – widen search interval.",
            option_price,
            max_vola,
            price_max,
        )
        return math.nan

    # Initial guess – half way of the bracket or BS heuristic
    sigma = 0.5
    sigma = min(max(sigma, min_vola), max_vola)

    price, vega = _price_vega(sigma)
    if price > option_price:
        high, low = sigma, min_vola
    else:
        high, low = max_vola, sigma

    for it in range(max_iter):
        rel_err = abs(price / option_price - 1.0)
        if rel_err < relative_tolerance:
            break

        # Newton step
        if vega > 0:
            sigma_new = sigma - (price - option_price) / vega
        else:
            sigma_new = (high + low) * 0.5  # fallback

        # Enforce bracketing
        if not (low < sigma_new < high):
            sigma_new = 0.5 * (high + low)

        sigma = sigma_new
        price, vega = _price_vega(sigma)

        # Update bracket
        if price > option_price:
            high = sigma
        else:
            low = sigma

    return float(sigma)


# Vectorised convenience wrapper
implied_volatilities = np.vectorize(implied_volatility, otypes=[float])


# ---------------------------------------------------------------------------
# 2.  Equivalent jump-diffusion volatility to match a BS ATM put
# ---------------------------------------------------------------------------


def equivalent_jump_vola_to_bs(
    bs_vola: float,
    time: float,
    *,
    const_short_rate: float = 0.0,
    const_default_intensity: float = 0.0,
    discount_factor_fcn: DiscountFactorFcnType | None = None,
    survival_probability_fcn: TermStructFcnType | None = None,
    dividends: pd.DataFrame | None = None,
    borrow_cost: float = 0.0,
    dividend_rate: float = 0.0,
    relative_tolerance: float = 1e-6,
    max_iter: int = 100,
) -> float:
    """Jump-diffusion volatility that reproduces a Black–Scholes ATM *put* price.

    The function equates the price of one dollar at-the-money **put** under
    (i) a standard Black–Scholes model with volatility ``bs_vola`` **and no
    default**, and
    (ii) a jump-to-default model with constant hazard λ and *unknown*
    volatility σ.  The returned σ can be fed into the PDE solver for a
    jump-to-default equity process.

    Examples
    --------
    Constant curves for *r* and λ::

        >>> jv = equivalent_jump_vola_to_bs(
        ...     bs_vola=0.20,
        ...     time=1.0,
        ...     const_short_rate=0.03,
        ...     const_default_intensity=0.05
        ... )
        >>> round(jv, 4)
        0.1195

    Using flat-forward discount and survival curves::

        >>> import math
        >>> DF = lambda T, t: math.exp(-0.025 * (T - t))          # 2.5 % curve
        >>> SP = lambda T, t: math.exp(-0.04 * (T - t))           # 4 % hazard
        >>> equivalent_jump_vola_to_bs(
        ...     bs_vola=0.18,
        ...     time=2.0,
        ...     discount_factor_fcn=DF,
        ...     survival_probability_fcn=SP
        ... )
    """
    # Term-structure fall-backs
    if discount_factor_fcn is None:
        discount_factor_fcn = cast(
            DiscountFactorFcnType,
            lambda T, t, r=const_short_rate: math.exp(-r * (T - t)),
        )  # noqa: E731
    if survival_probability_fcn is None:
        survival_probability_fcn = cast(
            TermStructFcnType,
            lambda T, t, h=const_default_intensity: math.exp(-h * (T - t)),
        )  # noqa: E731  # noqa: E731

    # Market reference price (default-free)
    ref_price = black_scholes_on_term_structures(
        callput=PUT,
        S0=1.0,
        K=1.0,
        time=time,
        const_volatility=bs_vola,
        discount_factor_fcn=discount_factor_fcn,
        survival_probability_fcn=cast(
            TermStructFcnType, lambda T, t: 1.0
        ),  # no default
        dividends=dividends,
        borrow_cost=borrow_cost,
        dividend_rate=dividend_rate,
    )["Price"]

    # Price with *tiny* vol to obtain lower bound
    min_price = black_scholes_on_term_structures(
        callput=PUT,
        S0=1.0,
        K=1.0,
        time=time,
        const_volatility=1e-10,
        discount_factor_fcn=discount_factor_fcn,
        survival_probability_fcn=survival_probability_fcn,
        dividends=dividends,
        borrow_cost=borrow_cost,
        dividend_rate=dividend_rate,
    )["Price"]

    if ref_price <= min_price + 1e-12:
        logger_iv.warning(
            "Survival probability too low – even σ→0 exceeds reference price."
        )
        return math.nan

    # Newton iterations
    sigma = 0.9 * bs_vola  # heuristic start
    for it in range(max_iter):
        price_dict = black_scholes_on_term_structures(
            callput=PUT,
            S0=1.0,
            K=1.0,
            time=time,
            const_volatility=sigma,
            discount_factor_fcn=discount_factor_fcn,
            survival_probability_fcn=survival_probability_fcn,
            dividends=dividends,
            borrow_cost=borrow_cost,
            dividend_rate=dividend_rate,
        )
        price = price_dict["Price"]
        vega = price_dict["Vega"]

        rel_err = abs(price / ref_price - 1.0)
        if rel_err < relative_tolerance:
            return float(sigma)

        # Newton step with safeguard
        sigma -= (price - ref_price) / vega
        if sigma < 0:
            logger_iv.warning("Negative σ encountered – no feasible solution.")
            return math.nan

    logger_iv.warning("Jump volatility solver did not converge within max_iter.")
    return float("nan")


def equivalent_bs_vola_to_jump(
    jump_process_vola: float,
    time: float,
    *,
    const_short_rate: float = 0.0,
    const_default_intensity: float = 0.0,
    discount_factor_fcn: DiscountFactorFcnType | None = None,
    survival_probability_fcn: TermStructFcnType | None = None,
    dividends: pd.DataFrame | None = None,
    borrow_cost: float = 0.0,
    dividend_rate: float = 0.0,
    relative_tolerance: float = 1e-6,
    max_iter: int = 100,
) -> float:
    """
    Black-Scholes volatility *σ<sub>BS</sub>* that matches a jump-to-default model with
    volatility *σ<sub>jump</sub>* and hazard λ.

    The equality is enforced on the price of an at-the-money **put** with
    *S₀ = K = 1* and maturity ``time``.

    Parameters
    ----------
    jump_process_vola
        Volatility of the default-free diffusion component in the *jump*
        model (σ<sub>jump</sub>).
    time
        Time to expiry (years).
    const_short_rate
        Flat risk-free rate *r* if `discount_factor_fcn` is omitted.
    const_default_intensity
        Flat hazard λ if `survival_probability_fcn` is omitted.
    discount_factor_fcn
        Discount curve ``DF(T, t)``; default is flat *r*.
    survival_probability_fcn
        Survival curve ``SP(T, t)``; default is flat λ.
    dividends, borrow_cost, dividend_rate
        Passed through to the option pricer.
    relative_tolerance
        Relative price mismatch at which to stop.
    max_iter
        Maximum Newton iterations.

    Returns
    -------
    float
        Black-Scholes volatility σ<sub>BS</sub>.  ``math.nan`` is returned if
        the solver fails to converge or encounters an infeasible region.

    Examples
    --------
    >>> bsiv = equivalent_bs_vola_to_jump(
    ...     jump_process_vola=0.30, time=2.0,
    ...     const_short_rate=0.025, const_default_intensity=0.04
    ... )
    >>> round(bsiv, 4)
    0.3687
    """
    # Flat-curve fall-backs
    if discount_factor_fcn is None:
        discount_factor_fcn = cast(
            DiscountFactorFcnType,
            lambda T, t, r=const_short_rate: math.exp(-r * (T - t)),  # noqa: E731
        )  # noqa: E731
    if survival_probability_fcn is None:
        survival_probability_fcn = cast(
            TermStructFcnType,
            lambda T, t, h=const_default_intensity: math.exp(-h * (T - t)),
        )  # noqa: E731

    # Price under *jump* model
    defaultable_price = black_scholes_on_term_structures(
        callput=PUT,
        S0=1.0,
        K=1.0,
        time=time,
        const_volatility=jump_process_vola,
        discount_factor_fcn=discount_factor_fcn,
        survival_probability_fcn=survival_probability_fcn,
        dividends=dividends,
        borrow_cost=borrow_cost,
        dividend_rate=dividend_rate,
    )["Price"]

    # Newton iteration on σ_BS (start at jump sigma)
    sigma_bs = jump_process_vola
    for iteration in range(max_iter):
        bs_output = black_scholes_on_term_structures(
            callput=PUT,
            S0=1.0,
            K=1.0,
            time=time,
            const_volatility=sigma_bs,
            discount_factor_fcn=discount_factor_fcn,
            survival_probability_fcn=cast(
                TermStructFcnType, lambda T, t: 1.0
            ),  # no default
            dividends=dividends,
            borrow_cost=borrow_cost,
            dividend_rate=dividend_rate,
        )
        price_bs = bs_output["Price"]
        vega_bs = bs_output["Vega"]

        rel_err = abs(price_bs / defaultable_price - 1.0)
        if rel_err < relative_tolerance:
            logger_eq.info(
                "Converged in %s iterations; σ_BS=%.6g (rel err=%.2e)",
                iteration + 1,
                sigma_bs,
                rel_err,
            )
            return float(sigma_bs)

        # Newton step
        sigma_bs -= (price_bs - defaultable_price) / vega_bs
        if sigma_bs <= 0.0:
            logger_eq.warning(
                "Negative σ encountered during iteration – no feasible solution."
            )
            return math.nan

        logger_eq.debug(
            "Iter %s: σ_BS=%.6g price=%.6g target=%.6g rel err=%.2e",
            iteration + 1,
            sigma_bs,
            price_bs,
            defaultable_price,
            rel_err,
        )

    logger_eq.warning("Solver did not converge within max_iter=%s.", max_iter)
    return math.nan


def american_implied_volatility(  # type: ignore[no-untyped-def]
    option_price: float,
    callput: int,
    S0: float,
    K: float,
    time: float,
    *,
    const_default_intensity: float = 0.0,
    survival_probability_fcn: TermStructFcnType | None = None,
    default_intensity_fcn: TermStructFcnType | None = None,
    discount_factor_fcn: DiscountFactorFcnType | None = None,
    num_time_steps: int = 30,
    structure_constant: float = 2.0,
    std_devs_width: float = 5.0,
    relative_tolerance: float = 1.0e-4,
    max_iter: int = 100,
    max_vola: float = 4.00,
    **kwargs,
) -> float:
    """
    Implied volatility for an American option with equity-independent
    term structures.

    This routine uses a finite–difference grid solver to price the
    American option under a default–intensity model whose survival
    probabilities are *not* linked to the underlying equity price.
    The resulting option values are passed through a bisective root
    search until a single, constant Black–Scholes volatility is found
    that reproduces the observed *option_price*.

    Parameters
    ----------
    option_price : float
        Observed market price that the model must match.
    callput : {1, -1}
        +1 for a call, −1 for a put.
    S0 : float
        Current underlying spot price.
    K : float
        Strike price.
    time : float
        Time from *t = 0* to expiration, expressed in years.
    const_default_intensity : float, default 0.0
        Constant hazard rate λ used when no term-structure function is
        supplied.
    survival_probability_fcn : Callable[[T, t], float], optional
        Function returning the risk-neutral survival probability
        P(τ > T | τ > t).  Defaults to
        ``lambda T, t: math.exp(-const_default_intensity * (T - t))``.
    default_intensity_fcn : Callable[[t, S], float], optional
        Instantaneous default intensity λ(t, S).  Defaults to
        ``lambda t, S: const_default_intensity``.
    discount_factor_fcn : Callable[[T, t], float], optional
        Risk-free discount factor D(T, t).  If *None*, the function
        ``lambda T, t: math.exp(-const_short_rate * (T - t))`` is used,
        where *const_short_rate* may be provided in *kwargs*.
    num_time_steps : int, default 30
        Number of time steps in the finite-difference grid.
    structure_constant : float, default 2.0
        Controls non-uniform grid concentration around the early-exercise
        boundary.
    std_devs_width : float, default 5.0
        Grid width in standard deviations.
    relative_tolerance : float, default 1e-4
        Relative tolerance on the option price for terminating the root
        finder.
    max_iter : int, default 100
        Maximum number of root-finder iterations.
    max_vola : float, default 4.0
        Upper bound on volatility explored by the root finder.
    **kwargs
        Additional arguments forwarded to
        `ragtop.blackscholes.American` and to the European helper
        function `implied_volatility_with_term_struct`.

    Returns
    -------
    float
        The Black–Scholes volatility σ that reproduces *option_price*.

    Notes
    -----
    •  The implementation is left as an exercise.
    •  Raise `NotImplementedError` until completed.

    See Also
    --------
    implied_volatility_with_term_struct :
        European implied volatility under the same term-structure
        assumptions.
    american :
        Grid-based American option pricer used internally.
    """
    raise NotImplementedError("Exercise for the student")
