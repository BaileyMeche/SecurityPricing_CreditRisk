from __future__ import annotations

import logging
from typing import Any
from typing import Callable

import numpy as np
import pandas as pd
from numpy.typing import NDArray

from .extrapolation import spline_extrapolate


logger_divs = logging.getLogger(f"{__name__}.cashflows.dividends")
logger_cpn = logging.getLogger(f"{__name__}.cashflows.coupons")

# ---------------------------------------------------------------------------
# Type aliases
# ---------------------------------------------------------------------------

# discount_factor_fcn(from_time, to_time) → ndarray | float
DiscountFactorFcn = Callable[[NDArray[Any] | float, NDArray[Any] | float], NDArray[Any]]


def shift_for_dividends(
    grid_values_before_shift: NDArray[Any],
    stock_prices: NDArray[Any],
    div_sum: NDArray[Any] | float,
) -> NDArray[Any]:
    """
    Shifts grid values via natural cubic spline interpolation, and
    linear extrapolation (consistent with Neumann boundary conditions).
    """
    shifted_prices = stock_prices - div_sum

    return spline_extrapolate(
        stock_prices,
        grid_values_before_shift,
        shifted_prices,
    )


def time_adj_dividends(
    relevant_divs: pd.DataFrame,
    t_final: float,
    r: NDArray[Any] | float,
    h: NDArray[Any] | float,
    S: NDArray[Any],
    S0: NDArray[Any] | float,
) -> NDArray[Any] | float:
    """Present-value the fixed and proportional parts of each dividend.

    Args:
        relevant_divs: Data-frame with columns ``time``, ``fixed``,
            ``proportional``.
        t_final: Time at which values are required (usually ``t + dt``).
        r: Risk-free rate.
        h: Default intensities (scalar or array broadcastable to the shape of
            `S`).
        S: Stock‐price grid (length *N*).
        S0: Spot price of the underlying at time zero.

    Returns:
        `numpy.ndarray`: Dividend sums for every stock level in `S`
        (shape ``(N,)``).
    """
    times = relevant_divs["time"].to_numpy()
    fixed = relevant_divs["fixed"].to_numpy()
    proportional = relevant_divs["proportional"].to_numpy()

    # Ensure `h` is broadcastable with `S`
    h_vec = np.full_like(S, h) if np.isscalar(h) else np.asarray(h)

    # Outer product to obtain a matrix (M dividends × N stock levels)
    inv_discount = np.exp(np.outer(t_final - times, r + h_vec))  # carry forward

    fixed_amt = inv_discount * fixed[:, None]
    proportional_amt = inv_discount * proportional[:, None] * (S / S0)

    div_amt_by_price = fixed_amt + proportional_amt
    div_sum = div_amt_by_price.sum(axis=0)  # one per stock level
    return div_sum


def adjust_for_dividends(
    grid_values: NDArray[Any],
    t: float,
    dt: float,
    r: float,
    h: NDArray[Any] | float,
    S: NDArray[Any],
    S0: float,
    dividends: pd.DataFrame | None,
) -> NDArray[Any]:
    """Apply discrete dividend adjustments to a grid of instrument values.

    Args:
        grid_values: Shape ``(N, L)`` — *N* stock levels by *L* instrument
            layers. If *L* equals 1 the array may be one-dimensional.
        t: Current time.
        dt: Size of the time-step just executed.
        r: Risk-free rate.
        h: Default intensities (scalar or array broadcastable to the shape of
            `S`).
        S: Stock‐price grid (length *N*).
        S0: Spot price at time zero.
        dividends: All declared dividends as a data-frame with columns
            ``time``, ``fixed``, ``proportional``.  May be ``None`` or empty.

    Returns:
        `numpy.ndarray`: Grid values with dividend effects included.  Shape
        matches the input `grid_values`.
    """
    n_nodes = S.size
    if grid_values.shape[0] != n_nodes:
        raise ValueError(
            "grid_values first dimension "
            f"({grid_values.shape[0]}) must match len(S) ({n_nodes})."
        )

    logger_divs.info(
        f"adjust_for_dividends(): grid shape={grid_values.shape}, " f"S.size={n_nodes}"
    )

    if dividends is None or dividends.empty:
        logger_divs.debug("No discrete dividends supplied.")
        return grid_values

    # Select dividends whose ex-dates fall in (t, t + dt]
    in_interval = (dividends["time"] > t) & (dividends["time"] <= t + dt)
    relevant_divs = dividends.loc[in_interval, ["time", "fixed", "proportional"]]

    if relevant_divs.empty:
        logger_divs.info("No dividends in the interval (%s, %s].", t, t + dt)
        return grid_values

    logger_divs.info("Found %s dividends in (%s, %s].", len(relevant_divs), t, t + dt)

    div_sum = time_adj_dividends(relevant_divs, t + dt, r, h, S, S0)

    if not np.any(div_sum):
        return grid_values  # nothing to do

    # -----------------------------------------------------------------------
    # Apply the shift, supporting one or many instrument layers
    # -----------------------------------------------------------------------
    if grid_values.ndim == 1 or grid_values.shape[1] == 1:
        logger_divs.info("Dividend adjustment on a single instrument layer.")
        adjusted = shift_for_dividends(grid_values, S, div_sum)
        return adjusted.reshape(-1, 1) if grid_values.ndim == 2 else adjusted

    logger_divs.info(f"Dividend adjustment on {grid_values.shape[1]} layers.")
    adjusted_layers = [
        shift_for_dividends(grid_values[:, j], S, div_sum)
        for j in range(grid_values.shape[1])
    ]
    return np.column_stack(adjusted_layers)


def value_from_prior_coupons(
    t: float,
    coupons_df: pd.DataFrame,
    discount_factor_fcn: DiscountFactorFcn,
    model_t: float = 0.0,
) -> float:
    """Present-value coupons already paid between *model_t* and *t*.

    Args:
        t: Valuation time.
        coupons_df: Data-frame with columns ``payment_time`` and
            ``payment_size``.
        discount_factor_fcn: Callable such that
            ``discount_factor_fcn(payment_time, t)`` returns the
            time-*t* discount factor applicable to a coupon paid at
            ``payment_time``.
        model_t: Lower bound; coupons with ``payment_time`` ≤ *model_t* are
            ignored.

    Returns:
        Present value of past coupons (scalar).
    """
    mask = (coupons_df["payment_time"] <= t) & (coupons_df["payment_time"] > model_t)
    coups = coupons_df.loc[mask]

    if coups.empty:
        logger_cpn.debug(f"No past coupons between {model_t} and {t}.")
        return 0.0

    disc = discount_factor_fcn(coups["payment_time"].to_numpy(), t)
    pv = (coups["payment_size"].to_numpy() / disc).sum()

    logger_cpn.debug(
        f"Past coupons PV between {model_t} and {t}: {pv:.6g} "
        f"over {len(coups)} payments."
    )
    return float(pv)


def accelerated_coupon_value(
    t: float,
    coupons_df: pd.DataFrame,
    discount_factor_fcn: DiscountFactorFcn,
    acceleration_t: float = float("inf"),
) -> float:
    """Present-value future coupons up to *acceleration_t* under acceleration.

    Args:
        t: Valuation time (start of acceleration window).
        coupons_df: Data-frame with columns ``payment_time`` and
            ``payment_size``.
        discount_factor_fcn: Callable such that
            ``discount_factor_fcn(t, payment_time)`` returns the contractual
            *acceleration* discount factor.
        acceleration_t: Latest payment time considered for acceleration.

    Returns:
        Present value of accelerated coupons (scalar).
    """
    mask = (coupons_df["payment_time"] <= acceleration_t) & (
        coupons_df["payment_time"] > t
    )
    coups = coupons_df.loc[mask]

    if coups.empty:
        logger_cpn.debug(f"No coupons to accelerate between {t} and {acceleration_t}.")
        return 0.0

    disc = discount_factor_fcn(t, coups["payment_time"].to_numpy())
    pv = (coups["payment_size"].to_numpy() / disc).sum()

    logger_cpn.debug(
        f"Accelerated coupons PV between {t} and {acceleration_t}: "
        f"{pv:.6g} over {len(coups)} payments."
    )
    return float(pv)


def coupon_value_at_exercise(
    t: float,
    coupons_df: pd.DataFrame,
    discount_factor_fcn: DiscountFactorFcn,
    model_t: float = 0.0,
    accelerate_future_coupons: bool = False,
    acceleration_discount_factor_fcn: DiscountFactorFcn | None = None,
    acceleration_t: float = float("inf"),
) -> float:
    """Present-value coupon cash-flows at conversion/exercise time *t*.

    Combines:
      • Past coupons paid between *model_t* and *t*.
      • Optionally, accelerated future coupons up to *acceleration_t*.

    Args:
        t: Exercise/valuation time.
        coupons_df: Data-frame with columns ``payment_time`` and
            ``payment_size``.
        discount_factor_fcn: Standard discount-factor function.
        model_t: Lower bound for past-coupon valuation.
        accelerate_future_coupons: If ``True`` include accelerated coupons.
        acceleration_discount_factor_fcn: Discount-factor function used for
            acceleration.  Defaults to `discount_factor_fcn` if ``None``.
        acceleration_t: Upper bound for accelerated coupon payments.

    Returns:
        Scalar present value of all relevant coupons.
    """
    acceleration_discount_factor_fcn = (
        acceleration_discount_factor_fcn or discount_factor_fcn
    )

    past_value = value_from_prior_coupons(
        t,
        coupons_df,
        discount_factor_fcn=discount_factor_fcn,
        model_t=model_t,
    )

    accel_value = 0.0
    if accelerate_future_coupons:
        accel_value = accelerated_coupon_value(
            t,
            coupons_df,
            discount_factor_fcn=acceleration_discount_factor_fcn,
            acceleration_t=acceleration_t,
        )

    total = past_value + accel_value

    logger_cpn.info(
        f"Coupon PV at t={t}: past={past_value:.6g}, "
        f"accelerated={accel_value:.6g} → total={total:.6g}"
    )
    return total
