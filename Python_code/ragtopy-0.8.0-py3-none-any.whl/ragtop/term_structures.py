from __future__ import annotations

import logging
from typing import Any
from typing import Callable
from typing import Protocol
from typing import overload
from typing import runtime_checkable

import numpy as np
import pandas as pd
from numpy.typing import NDArray


logger_ts = logging.getLogger(f"{__name__}.term_structures")


# Term struct calls have an optional third argument, e.g a constant rate
@runtime_checkable
class TermStructFcnType(Protocol):
    """For typing of callable volatility, hazard and rates discounting"""

    @overload
    def __call__(self, t: float, T: float, r: float | None = ...) -> float: ...
    @overload
    def __call__(
        self, t: NDArray[Any], T: float, r: float | None = ...
    ) -> NDArray[Any]: ...
    @overload
    def __call__(
        self, t: float, T: NDArray[Any], r: float | None = ...
    ) -> NDArray[Any]: ...
    @overload
    def __call__(
        self, t: NDArray[Any], T: NDArray[Any], r: float | None = ...
    ) -> NDArray[Any]: ...


DiscountFactorFcnType = TermStructFcnType


@overload
def trivial_discounting(t: float, T: float, r: float | None = ...) -> float: ...


@overload
def trivial_discounting(
    t: NDArray[Any], T: float, r: float | None = ...
) -> NDArray[Any]: ...


@overload
def trivial_discounting(
    t: float, T: NDArray[Any], r: float | None = ...
) -> NDArray[Any]: ...


@overload
def trivial_discounting(
    t: NDArray[Any], T: NDArray[Any], r: float | None = ...
) -> NDArray[Any]: ...


def trivial_discounting(
    t: float | NDArray[Any],
    T: float | NDArray[Any],
    r: float | None = None,  # optional 3rd argument
) -> float | NDArray[Any]:
    """Discount factor that always returns 1."""
    if isinstance(t, float) and isinstance(T, float):
        return 1.0  # scalar → scalar
    return np.ones_like(np.asarray(t) * np.asarray(T))


# ---------------------------------------------------------------------------
# Variance term structure
# ---------------------------------------------------------------------------


def variance_cumulation_from_vols(
    vols_df: pd.DataFrame,
) -> Callable[[float | NDArray[Any], float | NDArray[Any]], NDArray[Any]]:
    """Return ``Var(T, t)`` from a *piecewise constant* volatility schedule.

    The input data-frame must contain two numeric columns:

    ========  ============================================================
    Column    Description
    --------  ------------------------------------------------------------
    time      Anchor times :math:`t_1 < t_2 < … < t_N`  (year fractions)
    volatility
              Spot volatilities σ(*t*) quoted at the same anchors
    ========  ============================================================

    The resulting callable assumes:
        • σ(*t*) is constant inside each interval
          :math:`[t_i, t_{i+1})`, and
        • σ(*t*) = σ(*t_N*) for *t* ≥ *t_N*.

    Parameters
    ----------
    vols_df
        Volatility term structure as described above (must be sorted).

    Returns
    -------
    Callable
        ``Var(T, t)`` that returns the *cumulated variance*
        :math:`\\int_t^T σ^2(u) \\, du`.  Accepts scalar or NumPy array
        arguments and broadcasts in the NumPy sense.

    Raises
    ------
    ValueError
        If the term structure implies negative (forward) variance.
    """
    # ------------------------------------------------------------------ #
    # Basic validation and pre-processing
    # ------------------------------------------------------------------ #
    times = vols_df["time"].to_numpy(dtype=float)
    vols = vols_df["volatility"].to_numpy(dtype=float)

    if not np.all(np.diff(times) > 0):
        raise ValueError("`time` column must be strictly increasing.")

    cum_vars = np.concatenate(([0.0], (vols**2) * times))
    if (cum_vars < 0).any():
        raise ValueError("Negative cumulative variance encountered.")

    fwd_vars = np.diff(cum_vars)
    if (fwd_vars < 0).any():
        raise ValueError("Negative *forward* variance encountered.")

    # Piecewise-constant forward vols
    dt = np.diff(np.concatenate(([0.0], times)))
    fwd_vols = np.sqrt(fwd_vars / dt)
    max_t = times[-1]
    last_fwd_vol = fwd_vols[-1]

    # ------------------------------------------------------------------ #
    # Inner helper: cumulative variance from 0 to x
    # ------------------------------------------------------------------ #
    def _cum_var_0(x: float | NDArray[Any]) -> NDArray[Any]:
        """Variance from 0 to *x* (vectorised)."""
        x_arr = np.asarray(x, dtype=float)
        out = np.empty_like(x_arr)

        # Region 1: x == 0
        mask0 = x_arr == 0.0
        out[mask0] = 0.0

        # Region 2: x >= last anchor
        mask2 = x_arr >= max_t
        out[mask2] = cum_vars[-1] + last_fwd_vol**2 * (x_arr[mask2] - max_t)

        # Region 3: inside the tabulated range
        mask1 = ~(mask0 | mask2)
        if mask1.any():
            idx = np.searchsorted(times, x_arr[mask1], side="right")
            dt_local = x_arr[mask1] - np.concatenate(([0.0], times))[idx]
            out[mask1] = cum_vars[idx] + (fwd_vols[idx] ** 2) * dt_local

        return out

    def var_cum(T: float | NDArray[Any], t: float | NDArray[Any] = 0.0) -> NDArray[Any]:
        """Cumulated variance from *t* to *T*."""
        T_arr, t_arr = np.broadcast_arrays(np.asarray(T, float), np.asarray(t, float))
        cv = _cum_var_0(T_arr) - _cum_var_0(t_arr)

        if np.any((T_arr > t_arr) & (cv <= 0.0)):
            raise ValueError(
                f"Nonsensical non-positive variance detected for "
                f"intervals where T>t (min {cv.min()})."
            )
        return cv

    return var_cum


# ---------------------------------------------------------------------------
# Discount curve from spot (zero) rates
# ---------------------------------------------------------------------------


def spot_to_df_fcn(
    yield_curve: pd.DataFrame,
) -> Callable[[float | NDArray[Any], float | NDArray[Any]], NDArray[Any]]:
    """Return ``DF(T, t)`` from a piecewise-constant spot curve.

    The callable follows a *flat-forward* construction: spot rates are assumed
    constant inside each interval ``[t_i, t_{i+1})`` and equal to the last
    quoted rate beyond the final anchor.

    Parameters
    ----------
    yield_curve
        Data-frame with two numeric columns:

        =====  ==============================
        time   Anchor times (ascending order)
        rate   Continuously-compounded spots
        =====  ==============================

    Returns
    -------
    Callable
        ``DF(T, t)`` delivering the discount factor between *t* and *T*.
        Supports scalar or NumPy array inputs.
    """
    # ------------------------------------------------------------------ #
    # Precompute discount factors and flat-forward rates
    # ------------------------------------------------------------------ #
    times = yield_curve["time"].to_numpy(dtype=float)
    rates = yield_curve["rate"].to_numpy(dtype=float)

    if not np.all(np.diff(times) > 0):
        raise ValueError("`time` column must be strictly increasing.")

    dfs = np.exp(-times * rates)  # zero-curve discount factors
    fwd_rates = -np.log(dfs[1:] / dfs[:-1]) / np.diff(times)
    fwd_full = np.empty_like(rates)
    fwd_full[:-1] = fwd_rates
    fwd_full[-1] = fwd_rates[-1]  # extend last forward rate indefinitely

    # ------------------------------------------------------------------ #
    # Helper disc factor from 0 to x
    # ------------------------------------------------------------------ #
    def _df_0(x: float | NDArray[Any]) -> NDArray[Any]:
        x_arr = np.asarray(x, dtype=float)
        out = np.empty_like(x_arr)

        idx = np.searchsorted(times, x_arr, side="right")

        # x beyond last anchor → use last forward rate
        mask_last = idx == len(times)
        if mask_last.any():
            dt = x_arr[mask_last] - times[-1]
            out[mask_last] = dfs[-1] * np.exp(-fwd_full[-1] * dt)

        # x between anchors (or x==time[0])
        mask_other = ~mask_last
        if mask_other.any():
            n = idx[mask_other]  # idx == 0 uses first zero rate directly
            dt = x_arr[mask_other] - np.where(n == 0, 0.0, times[n - 1])
            base_df = np.where(n == 0, 1.0, dfs[n - 1])
            fwd_rate = np.where(n == 0, rates[0], fwd_full[n - 1])
            out[mask_other] = base_df * np.exp(-fwd_rate * dt)

        return out

    # ------------------------------------------------------------------ #
    # Public callable DF(T, t)
    # ------------------------------------------------------------------ #
    def discount_factor_callable(
        T: float | NDArray[Any],
        t: float | NDArray[Any] = 0.0,
        **_: dict[str, Any],
    ) -> NDArray[Any]:
        """Discount factor from *t* to *T*."""
        T_arr, t_arr = np.broadcast_arrays(np.asarray(T, float), np.asarray(t, float))
        return _df_0(T_arr) / _df_0(t_arr)

    return discount_factor_callable
